=== AIO Webcare – Complete Site Management ===
Contributors: aiowebcare
Donate link: https://aiowebcare.com/
Tags: remote management, maintenance, updates, security, optimization, monitoring, api
Requires at least: 5.8
Tested up to: 6.8
Stable tag: 1.0.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Professional remote management solution with comprehensive site monitoring, security, and automated maintenance capabilities.

== Description ==

AIO Webcare is a powerful management solution that enables secure remote management of your sites through a comprehensive REST API interface. Perfect for agencies, developers, and site administrators who need to manage multiple site installations from a centralized dashboard.

**Core Features:**
* Remote WordPress management via secure API
* Real-time site status and health monitoring  
* One-click WordPress, plugin & theme updates
* Backup integration with UpdraftPlus support
* User management and role oversight
* Database optimization and cleanup tools
* Comment and revision management
* Security logging and audit trails
* Maintenance mode control
* Comprehensive performance metrics

**🔐 Enterprise-Grade Security**
* Secure API key authentication with rate limiting
* Comprehensive security logging and audit trails
* User capability verification for all operations
* CSRF protection and input validation
* Hash-based authentication with timing attack resistance

**📊 Comprehensive Site Monitoring**
* Real-time site status and health monitoring
* Plugin and theme management with update tracking
* User management and role oversight
* Performance metrics and server information
* Site core version monitoring
* Database size and optimization tracking

**⚡ Database Optimization**
* Database table optimization and repair
* Revision cleanup with configurable retention
* Spam comment removal
* Trash cleanup and orphaned metadata removal
* Expired transients cleanup
* Performance score calculation with recommendations

**🛡️ Advanced Security Features**
* Real-time security event logging
* Rate limiting protection
* Invalid access attempt tracking
* IP-based monitoring and logging
* Secure admin context for remote operations

Perfect for freelancers, agencies, and business owners who want secure, professional site maintenance capabilities.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/aiowebcare` directory, or install via WordPress Plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Configure settings under **AIO Webcare** in your WordPress dashboard.
4. Generate your secure API key from the settings page.
5. Use the API endpoints to connect with your remote management dashboard.

== Requirements ==

* PHP 7.4 or higher
* WordPress 5.8 or higher
* MySQL 5.6 or higher
* HTTPS recommended for API security
* Administrator privileges for full functionality

== Frequently Asked Questions ==

= How do I get my API key? =
After activation, go to AIO Webcare settings in your WordPress admin to generate your secure API key.

= Does this work with backup plugins? =
Yes, the plugin integrates with UpdraftPlus for comprehensive backup management. Backup endpoints provide status, configuration, and management capabilities.

= Is this plugin secure? =
Yes, all API calls use secure authentication with rate limiting, comprehensive logging, and hash-based verification.

= Can I manage multiple websites? =
Yes, each site gets its own API key and can be managed independently through the REST API endpoints.

= Can I roll back updates if something goes wrong? =
The plugin includes comprehensive logging and maintains site status information for monitoring update results.

= What optimization features are included? =
Database optimization, revision cleanup, spam removal, trash cleanup, transients cleanup, and orphaned metadata removal.

= Does this work with all themes and plugins? =
Yes, the plugin works at the WordPress core level and is compatible with all themes and plugins.

== Screenshots ==

1. Main dashboard showing site status and health metrics
2. Plugin and theme update management interface  
3. Database optimization and cleanup tools
4. User management and security monitoring panel
5. API settings and configuration screen

== Changelog ==

= 1.0.0 =
* Initial release with core maintenance features
* Secure API authentication system
* Real-time site monitoring capabilities
* Database optimization tools
* User and content management
* Security logging and audit trails
* Comment and revision management
* Update management system
* Performance metrics and health monitoring

== Upgrade Notice ==

= 1.0.0 =
First release of AIO Webcare – Professional WordPress Maintenance Plugin with comprehensive remote management capabilities.

== Support ==

For support and documentation, visit [aiowebcare.com](https://aiowebcare.com/)

== For Developers ==

This plugin provides comprehensive REST API endpoints for remote WordPress management. All endpoints require secure API key authentication and provide detailed response data for integration with external management systems.