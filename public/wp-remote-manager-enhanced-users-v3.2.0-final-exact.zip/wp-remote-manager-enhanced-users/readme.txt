WP Remote Manager Enhanced Users

A comprehensive WordPress plugin for remote site management and monitoring.

== Features ==
* Enhanced user management with detailed metadata
* Secure API endpoints with CORS support  
* Plugin and theme management
* WordPress core update detection
* Health monitoring and status reporting
* Maintenance mode management
* Backup status integration

== Installation ==
1. Upload the plugin files to /wp-content/plugins/wp-remote-manager-enhanced-users/
2. Activate the plugin through WordPress admin
3. Navigate to Settings > Remote Manager Enhanced
4. Copy your API key for use with the dashboard

== API Endpoints ==
* /wp-json/wrms/v1/status - Site status and information
* /wp-json/wrms/v1/health - Health check
* /wp-json/wrms/v1/updates - Available updates
* /wp-json/wrms/v1/plugins - Plugin management
* /wp-json/wrms/v1/themes - Theme management
* /wp-json/wrms/v1/users - User management
* /wp-json/wrms/v1/users/detailed - Detailed user information

== Changelog ==
= 3.2.0 Final =
* Enhanced security with hash_equals() API key verification
* Added detailed user metadata support
* Improved CORS handling
* Enhanced error logging and reporting
* Added comprehensive plugin and theme management
* WordPress 6.8+ compatibility
