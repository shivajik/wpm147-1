<?php
/**
 * Plugin Name: WP Remote Manager - Enhanced Users v3.2.0 Final (API Key Sync Fixed)
 * Description: Advanced WordPress Remote Manager plugin with comprehensive user management, security, and remote maintenance capabilities - API Key Sync Fixed
 * Version: 3.2.0
 * Author: AIO Webcare
 * Text Domain: wp-remote-manager-enhanced
 * Requires at least: 5.0
 * Tested up to: 6.8
 * Requires PHP: 7.4
 * Network: false
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit('Direct access denied.');
}

/**
 * Main WP Remote Manager Enhanced Users Class
 */
class WP_Remote_Manager_Enhanced_Users {
    
    private $version = '3.2.0';
    private $api_namespace = 'wrms/v1';
    private $option_name = 'wrm_api_key';
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('rest_api_init', array($this, 'register_routes'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('wp_login', array($this, 'track_user_login'), 10, 2);
        
        // Add security headers
        add_action('rest_api_init', array($this, 'add_cors_headers'));
        
        // Plugin activation hook
        register_activation_hook(__FILE__, array($this, 'activate_plugin'));
        
        // AJAX handlers for API key management
        add_action('wp_ajax_wrm_regenerate_key', array($this, 'ajax_regenerate_key'));
        add_action('wp_ajax_wrm_update_key', array($this, 'ajax_update_key'));
    }
    
    public function init() {
        // Generate API key if not exists
        if (!get_option($this->option_name)) {
            $this->generate_api_key();
        }
    }
    
    /**
     * Register REST API routes
     */
    public function register_routes() {
        // Core status endpoints
        register_rest_route($this->api_namespace, '/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_status'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        register_rest_route($this->api_namespace, '/health', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_health'),
            'permission_callback' => '__return_true'
        ));
        
        // Update management endpoints
        register_rest_route($this->api_namespace, '/updates', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_updates'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        register_rest_route($this->api_namespace, '/updates/perform', array(
            'methods' => 'POST',
            'callback' => array($this, 'perform_updates'),
            'permission_callback' => array($this, 'verify_admin_capabilities')
        ));
        
        // Plugin management endpoints
        register_rest_route($this->api_namespace, '/plugins', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_plugins'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        register_rest_route($this->api_namespace, '/plugins/activate', array(
            'methods' => 'POST',
            'callback' => array($this, 'activate_plugin_endpoint'),
            'permission_callback' => array($this, 'verify_admin_capabilities')
        ));
        
        register_rest_route($this->api_namespace, '/plugins/deactivate', array(
            'methods' => 'POST',
            'callback' => array($this, 'deactivate_plugin_endpoint'),
            'permission_callback' => array($this, 'verify_admin_capabilities')
        ));
        
        // Theme management endpoints
        register_rest_route($this->api_namespace, '/themes', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_themes'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        register_rest_route($this->api_namespace, '/themes/activate', array(
            'methods' => 'POST',
            'callback' => array($this, 'activate_theme_endpoint'),
            'permission_callback' => array($this, 'verify_admin_capabilities')
        ));
        
        // Enhanced user management endpoints
        register_rest_route($this->api_namespace, '/users', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_users'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        register_rest_route($this->api_namespace, '/users/detailed', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_users_detailed'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        // Maintenance mode endpoints
        register_rest_route($this->api_namespace, '/maintenance/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_maintenance_status'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        register_rest_route($this->api_namespace, '/maintenance/enable', array(
            'methods' => 'POST',
            'callback' => array($this, 'enable_maintenance'),
            'permission_callback' => array($this, 'verify_admin_capabilities')
        ));
        
        register_rest_route($this->api_namespace, '/maintenance/disable', array(
            'methods' => 'POST',
            'callback' => array($this, 'disable_maintenance'),
            'permission_callback' => array($this, 'verify_admin_capabilities')
        ));
        
        // Backup endpoints
        register_rest_route($this->api_namespace, '/backup/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_backup_status'),
            'permission_callback' => array($this, 'verify_api_key')
        ));
        
        // API key management endpoint
        register_rest_route($this->api_namespace, '/api-key/regenerate', array(
            'methods' => 'POST',
            'callback' => array($this, 'regenerate_api_key_endpoint'),
            'permission_callback' => array($this, 'verify_admin_capabilities')
        ));
    }
    
    /**
     * Verify API key
     */
    public function verify_api_key($request) {
        $api_key = $request->get_header('X-WRM-API-Key') ?: $request->get_header('X-WRMS-API-Key');
        $stored_key = get_option($this->option_name);
        
        if (!$api_key || !$stored_key) {
            return new WP_Error('missing_api_key', 'API key is required', array('status' => 401));
        }
        
        if (!hash_equals($stored_key, $api_key)) {
            return new WP_Error('invalid_api_key', 'Invalid API key', array('status' => 401));
        }
        
        return true;
    }
    
    /**
     * Verify admin capabilities
     */
    public function verify_admin_capabilities($request) {
        $api_check = $this->verify_api_key($request);
        if (is_wp_error($api_check)) {
            return $api_check;
        }
        
        if (!current_user_can('manage_options')) {
            return new WP_Error('insufficient_permissions', 'Admin permissions required', array('status' => 403));
        }
        
        return true;
    }
    
    /**
     * Get site status
     */
    public function get_status($request) {
        global $wpdb;
        
        // Get basic WordPress info
        $wp_version = get_bloginfo('version');
        $php_version = phpversion();
        $mysql_version = $this->get_mysql_version();
        
        // Get memory info
        $memory_limit = ini_get('memory_limit');
        $memory_usage = function_exists('memory_get_usage') ? round(memory_get_usage(true) / 1024 / 1024, 2) . ' MB' : 'Unknown';
        
        // Get disk usage (if possible)
        $disk_free = function_exists('disk_free_space') ? disk_free_space(ABSPATH) : false;
        $disk_total = function_exists('disk_total_space') ? disk_total_space(ABSPATH) : false;
        
        $disk_usage = array(
            'free' => $disk_free ? round($disk_free / 1024 / 1024 / 1024, 2) . ' GB' : 'Unknown',
            'total' => $disk_total ? round($disk_total / 1024 / 1024 / 1024, 2) . ' GB' : 'Unknown',
            'used' => ($disk_free && $disk_total) ? round(($disk_total - $disk_free) / 1024 / 1024 / 1024, 2) . ' GB' : 'Unknown'
        );
        
        // Count posts, pages, users
        $posts_count = wp_count_posts()->publish;
        $pages_count = wp_count_posts('page')->publish;
        $users_count = count_users()['total_users'];
        
        // Get plugins and themes count
        $plugins_count = 0;
        if (function_exists('get_plugins')) {
            $plugins_count = count(get_plugins());
        } else {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
            $plugins_count = count(get_plugins());
        }
        
        $themes_count = count(wp_get_themes());
        
        return rest_ensure_response(array(
            'success' => true,
            'site_info' => array(
                'name' => get_bloginfo('name'),
                'url' => home_url(),
                'admin_email' => get_option('admin_email'),
                'wordpress_version' => $wp_version,
                'php_version' => $php_version,
                'mysql_version' => $mysql_version,
                'memory_limit' => $memory_limit,
                'memory_usage' => $memory_usage,
                'disk_usage' => $disk_usage,
                'ssl_enabled' => is_ssl(),
                'posts_count' => $posts_count,
                'pages_count' => $pages_count,
                'users_count' => $users_count,
                'plugins_count' => $plugins_count,
                'themes_count' => $themes_count,
                'active_theme' => get_stylesheet(),
                'timezone' => get_option('timezone_string') ?: 'UTC'
            ),
            'plugin_info' => array(
                'name' => 'WP Remote Manager Enhanced Users',
                'version' => $this->version,
                'api_namespace' => $this->api_namespace
            ),
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get health status
     */
    public function get_health($request) {
        return rest_ensure_response(array(
            'status' => 'healthy',
            'plugin' => 'WP Remote Manager Enhanced Users',
            'version' => $this->version,
            'wordpress_version' => get_bloginfo('version'),
            'timestamp' => time()
        ));
    }
    
    /**
     * Get available updates
     */
    public function get_updates($request) {
        // Include required files
        if (!function_exists('get_core_updates')) {
            require_once ABSPATH . 'wp-admin/includes/update.php';
        }
        
        if (!function_exists('get_plugin_updates')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        // Force refresh of update data
        wp_update_plugins();
        wp_update_themes();
        wp_version_check();
        
        $updates = array(
            'wordpress' => $this->get_core_updates(),
            'plugins' => $this->get_plugin_updates(),
            'themes' => $this->get_theme_updates(),
            'total_count' => 0
        );
        
        // Count total updates
        $updates['total_count'] = count($updates['wordpress']) + count($updates['plugins']) + count($updates['themes']);
        
        return rest_ensure_response(array(
            'success' => true,
            'updates' => $updates,
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get WordPress core updates
     */
    private function get_core_updates() {
        $core_updates = get_core_updates();
        $updates = array();
        
        if (!empty($core_updates) && !isset($core_updates[0]->response) || $core_updates[0]->response !== 'latest') {
            foreach ($core_updates as $update) {
                if ($update->response === 'upgrade') {
                    $updates[] = array(
                        'current_version' => get_bloginfo('version'),
                        'new_version' => $update->version,
                        'package' => $update->package ?? '',
                        'url' => $update->url ?? '',
                        'partial' => $update->partial ?? false
                    );
                }
            }
        }
        
        return $updates;
    }
    
    /**
     * Get plugin updates
     */
    private function get_plugin_updates() {
        $plugin_updates = get_plugin_updates();
        $updates = array();
        
        foreach ($plugin_updates as $plugin_file => $plugin_data) {
            $updates[] = array(
                'plugin' => $plugin_data->Name,
                'plugin_file' => $plugin_file,
                'current_version' => $plugin_data->Version,
                'new_version' => $plugin_data->update->new_version,
                'package' => $plugin_data->update->package ?? '',
                'slug' => $plugin_data->update->slug ?? dirname($plugin_file),
                'tested' => $plugin_data->update->tested ?? '',
                'compatibility' => $plugin_data->update->compatibility ?? array()
            );
        }
        
        return $updates;
    }
    
    /**
     * Get theme updates
     */
    private function get_theme_updates() {
        $theme_updates = get_theme_updates();
        $updates = array();
        
        foreach ($theme_updates as $theme_slug => $theme_data) {
            $updates[] = array(
                'theme' => $theme_data->get('Name'),
                'slug' => $theme_slug,
                'current_version' => $theme_data->get('Version'),
                'new_version' => $theme_data->update['new_version'] ?? '',
                'package' => $theme_data->update['package'] ?? '',
                'url' => $theme_data->update['url'] ?? ''
            );
        }
        
        return $updates;
    }
    
    /**
     * Perform updates
     */
    public function perform_updates($request) {
        $update_type = sanitize_text_field($request->get_param('type'));
        $items = $request->get_param('items');
        
        if (!$update_type || !$items) {
            return new WP_Error('missing_parameters', 'Update type and items are required', array('status' => 400));
        }
        
        $results = array();
        
        switch ($update_type) {
            case 'wordpress':
                $results[] = $this->update_wordpress_core();
                break;
                
            case 'plugins':
                foreach ($items as $plugin) {
                    $results[] = $this->update_plugin($plugin);
                }
                break;
                
            case 'themes':
                foreach ($items as $theme) {
                    $results[] = $this->update_theme($theme);
                }
                break;
                
            case 'all':
                // Update WordPress core
                $results[] = $this->update_wordpress_core();
                
                // Update plugins
                $plugin_updates = $this->get_plugin_updates();
                foreach ($plugin_updates as $plugin) {
                    $results[] = $this->update_plugin($plugin['plugin_file']);
                }
                
                // Update themes
                $theme_updates = $this->get_theme_updates();
                foreach ($theme_updates as $theme) {
                    $results[] = $this->update_theme($theme['slug']);
                }
                break;
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'results' => $results,
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get all plugins
     */
    public function get_plugins($request) {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins', array());
        $plugins = array();
        
        foreach ($all_plugins as $plugin_path => $plugin_data) {
            $plugins[] = array(
                'name' => $plugin_data['Name'],
                'slug' => dirname($plugin_path),
                'version' => $plugin_data['Version'],
                'description' => $plugin_data['Description'],
                'author' => $plugin_data['Author'],
                'author_uri' => $plugin_data['AuthorURI'],
                'plugin_uri' => $plugin_data['PluginURI'],
                'active' => in_array($plugin_path, $active_plugins),
                'plugin_file' => $plugin_path,
                'network' => $plugin_data['Network'],
                'text_domain' => $plugin_data['TextDomain']
            );
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'plugins' => $plugins,
            'count' => count($plugins),
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get all themes
     */
    public function get_themes($request) {
        $themes = wp_get_themes();
        $current_theme = get_stylesheet();
        $theme_list = array();
        
        foreach ($themes as $theme_slug => $theme) {
            $theme_list[] = array(
                'name' => $theme->get('Name'),
                'slug' => $theme_slug,
                'version' => $theme->get('Version'),
                'description' => $theme->get('Description'),
                'author' => $theme->get('Author'),
                'author_uri' => $theme->get('AuthorURI'),
                'theme_uri' => $theme->get('ThemeURI'),
                'active' => ($theme_slug === $current_theme),
                'screenshot' => $theme->get_screenshot(),
                'tags' => $theme->get('Tags'),
                'template' => $theme->get_template()
            );
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'themes' => $theme_list,
            'count' => count($theme_list),
            'current_theme' => $current_theme,
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Enhanced Users Endpoint - Returns complete user data with email addresses
     */
    public function get_users($request) {
        $include_email = $request->get_param('include_email') !== 'false';
        $detailed = $request->get_param('detailed') === 'true';
        $limit = intval($request->get_param('limit')) ?: 100;
        
        $users = get_users(array(
            'fields' => 'all',
            'number' => min($limit, 500), // Maximum 500 users
            'orderby' => 'registered',
            'order' => 'DESC'
        ));
        
        $formatted_users = array();
        foreach ($users as $user) {
            $user_meta = get_userdata($user->ID);
            
            $user_data = array(
                'id' => (string) $user->ID,
                'username' => $user->user_login,
                'display_name' => $user->display_name,
                'registered_date' => $user->user_registered,
                'roles' => $user_meta->roles,
                'post_count' => count_user_posts($user->ID),
                'avatar_url' => get_avatar_url($user->ID, array('size' => 96))
            );
            
            // Always include email addresses (key enhancement)
            if ($include_email) {
                $user_data['email'] = $user->user_email;
            }
            
            // Add detailed information if requested
            if ($detailed) {
                $user_data = array_merge($user_data, array(
                    'first_name' => get_user_meta($user->ID, 'first_name', true),
                    'last_name' => get_user_meta($user->ID, 'last_name', true),
                    'nickname' => get_user_meta($user->ID, 'nickname', true),
                    'description' => get_user_meta($user->ID, 'description', true),
                    'website' => $user->user_url,
                    'last_login' => get_user_meta($user->ID, 'last_login', true),
                    'login_count' => get_user_meta($user->ID, 'login_count', true),
                    'capabilities' => $user_meta->allcaps ? array_keys(array_filter($user_meta->allcaps)) : array()
                ));
            }
            
            $formatted_users[] = $user_data;
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'users' => $formatted_users,
            'count' => count($formatted_users),
            'total_users' => count_users()['total_users'],
            'include_email' => $include_email,
            'detailed' => $detailed,
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get detailed users (alias for backward compatibility)
     */
    public function get_users_detailed($request) {
        $request->set_param('detailed', 'true');
        return $this->get_users($request);
    }
    
    /**
     * Get maintenance mode status
     */
    public function get_maintenance_status($request) {
        $maintenance_file = ABSPATH . '.maintenance';
        $is_active = file_exists($maintenance_file);
        
        $status = array(
            'maintenance_mode' => $is_active,
            'maintenance_file_exists' => $is_active,
            'timestamp' => current_time('c')
        );
        
        if ($is_active) {
            $content = file_get_contents($maintenance_file);
            if ($content) {
                $status['maintenance_message'] = $content;
            }
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'maintenance' => $status
        ));
    }
    
    /**
     * Enable maintenance mode
     */
    public function enable_maintenance($request) {
        $message = sanitize_text_field($request->get_param('message')) ?: 'Website is temporarily unavailable for maintenance. Please try again later.';
        
        $maintenance_content = "<?php\n\$upgrading = time();\n// Custom message: " . $message;
        
        $result = file_put_contents(ABSPATH . '.maintenance', $maintenance_content);
        
        if ($result === false) {
            return new WP_Error('maintenance_enable_failed', 'Failed to enable maintenance mode', array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Maintenance mode enabled',
            'maintenance_message' => $message,
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Disable maintenance mode
     */
    public function disable_maintenance($request) {
        $maintenance_file = ABSPATH . '.maintenance';
        
        if (!file_exists($maintenance_file)) {
            return rest_ensure_response(array(
                'success' => true,
                'message' => 'Maintenance mode was already disabled',
                'timestamp' => current_time('c')
            ));
        }
        
        $result = unlink($maintenance_file);
        
        if (!$result) {
            return new WP_Error('maintenance_disable_failed', 'Failed to disable maintenance mode', array('status' => 500));
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Maintenance mode disabled',
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get backup status (UpdraftPlus integration)
     */
    public function get_backup_status($request) {
        // Check if UpdraftPlus is active
        if (!class_exists('UpdraftPlus')) {
            return rest_ensure_response(array(
                'success' => false,
                'message' => 'UpdraftPlus plugin not found or not active',
                'backup_plugin_available' => false,
                'timestamp' => current_time('c')
            ));
        }
        
        // Get UpdraftPlus backup information
        $backup_info = array(
            'backup_plugin_available' => true,
            'plugin_name' => 'UpdraftPlus',
            'last_backup' => 'Not available',
            'next_backup' => 'Not scheduled',
            'backup_location' => 'Unknown'
        );
        
        // Try to get more detailed information if methods are available
        if (method_exists('UpdraftPlus', 'get_backupable_file_entities')) {
            $backup_info['backupable_entities'] = 'Available';
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'backup' => $backup_info,
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Add CORS headers
     */
    public function add_cors_headers() {
        add_filter('rest_pre_serve_request', function($value) {
            header('Access-Control-Allow-Origin: *');
            header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
            header('Access-Control-Allow-Headers: X-WRM-API-Key, X-WRMS-API-Key, Content-Type, Authorization');
            header('Access-Control-Allow-Credentials: true');
            return $value;
        });
    }
    
    /**
     * Generate secure API key (Fixed to generate 32-character keys)
     */
    private function generate_api_key() {
        $api_key = bin2hex(random_bytes(16)); // 32 character secure key
        update_option($this->option_name, $api_key);
        
        // Log the key generation
        error_log('WP Remote Manager: New API key generated - ' . substr($api_key, 0, 8) . '...');
        
        return $api_key;
    }
    
    /**
     * AJAX handler for regenerating API key
     */
    public function ajax_regenerate_key() {
        // Verify nonce and permissions
        if (!check_ajax_referer('wrm_ajax_nonce', 'nonce', false) || !current_user_can('manage_options')) {
            wp_die('Security check failed', 'Unauthorized', array('response' => 403));
        }
        
        $new_key = $this->generate_api_key();
        
        wp_send_json_success(array(
            'new_key' => $new_key,
            'message' => 'New API key generated successfully!'
        ));
    }
    
    /**
     * AJAX handler for updating API key manually
     */
    public function ajax_update_key() {
        // Verify nonce and permissions
        if (!check_ajax_referer('wrm_ajax_nonce', 'nonce', false) || !current_user_can('manage_options')) {
            wp_die('Security check failed', 'Unauthorized', array('response' => 403));
        }
        
        $new_key = sanitize_text_field($_POST['api_key']);
        
        if (strlen($new_key) < 32) {
            wp_send_json_error(array(
                'message' => 'API key must be at least 32 characters long.'
            ));
        }
        
        update_option($this->option_name, $new_key);
        
        wp_send_json_success(array(
            'message' => 'API key updated successfully!'
        ));
    }
    
    /**
     * REST API endpoint for regenerating API key
     */
    public function regenerate_api_key_endpoint($request) {
        $new_key = $this->generate_api_key();
        
        return rest_ensure_response(array(
            'success' => true,
            'new_api_key' => $new_key,
            'message' => 'New API key generated successfully',
            'timestamp' => current_time('c')
        ));
    }
    
    /**
     * Get MySQL version
     */
    private function get_mysql_version() {
        global $wpdb;
        return $wpdb->get_var("SELECT VERSION()");
    }
    
    /**
     * Track user login
     */
    public function track_user_login($user_login, $user) {
        update_user_meta($user->ID, 'last_login', current_time('mysql'));
        
        $login_count = get_user_meta($user->ID, 'login_count', true);
        $login_count = $login_count ? $login_count + 1 : 1;
        update_user_meta($user->ID, 'login_count', $login_count);
    }
    
    /**
     * Plugin activation
     */
    public function activate_plugin() {
        // Generate API key on activation
        if (!get_option($this->option_name)) {
            $this->generate_api_key();
        }
        
        // Log plugin activation
        error_log('WP Remote Manager Enhanced Users v' . $this->version . ' activated');
    }
    
    /**
     * Admin menu
     */
    public function admin_menu() {
        add_options_page(
            'WP Remote Manager Enhanced',
            'WP Remote Manager',
            'manage_options',
            'wp-remote-manager-enhanced',
            array($this, 'admin_page')
        );
    }
    
    /**
     * Admin page with improved API key management
     */
    public function admin_page() {
        // Handle form submissions
        if (isset($_POST['generate_api_key']) && check_admin_referer('wrm_admin_action', 'wrm_nonce')) {
            $new_key = $this->generate_api_key();
            echo '<div class="notice notice-success"><p><strong>New API Key Generated!</strong> Copy this key to your dashboard: <code>' . esc_html($new_key) . '</code></p></div>';
        }
        
        if (isset($_POST['update_api_key']) && check_admin_referer('wrm_admin_action', 'wrm_nonce')) {
            $new_key = sanitize_text_field($_POST['wrm_api_key']);
            if (strlen($new_key) >= 32) {
                update_option($this->option_name, $new_key);
                echo '<div class="notice notice-success"><p><strong>API Key Updated Successfully!</strong></p></div>';
            } else {
                echo '<div class="notice notice-error"><p><strong>Error:</strong> API key must be at least 32 characters long.</p></div>';
            }
        }
        
        $current_key = get_option($this->option_name);
        $site_url = home_url();
        ?>
        <div class="wrap">
            <h1><span class="dashicons dashicons-admin-network" style="margin-right: 8px;"></span>WP Remote Manager Enhanced Users</h1>
            <p>Advanced WordPress remote management plugin with comprehensive user data and enhanced security. <strong>API Key Sync Fixed Version</strong></p>
            
            <div class="card" style="max-width: none;">
                <h2>API Key Configuration</h2>
                
                <!-- Current API Key Display -->
                <div style="margin: 20px 0;">
                    <h3>Current API Key</h3>
                    <div style="background: #f9f9f9; padding: 15px; border-left: 4px solid #2271b1; margin: 10px 0;">
                        <code style="font-size: 14px; font-weight: bold; color: #2271b1;"><?php echo esc_html($current_key); ?></code>
                        <p style="margin: 10px 0 0 0; font-style: italic; color: #666;">Copy this key to your AIO Webcare dashboard</p>
                    </div>
                </div>
                
                <!-- Generate New Key -->
                <form method="post" style="margin: 20px 0; border-top: 1px solid #ddd; padding-top: 20px;">
                    <?php wp_nonce_field('wrm_admin_action', 'wrm_nonce'); ?>
                    <h3>Generate New API Key</h3>
                    <p>Click below to generate a completely new API key. This will invalidate the current key.</p>
                    <button type="submit" name="generate_api_key" class="button button-primary" onclick="return confirm('Generate a new API key? This will invalidate the current key and you will need to update your dashboard.')">
                        Generate New API Key
                    </button>
                </form>
                
                <!-- Update Existing Key -->
                <form method="post" style="margin: 20px 0; border-top: 1px solid #ddd; padding-top: 20px;">
                    <?php wp_nonce_field('wrm_admin_action', 'wrm_nonce'); ?>
                    <h3>Update API Key Manually</h3>
                    <p>If you have generated a key from your dashboard, paste it here to synchronize:</p>
                    <table class="form-table">
                        <tr>
                            <th scope="row">New API Key</th>
                            <td>
                                <input type="text" name="wrm_api_key" value="" class="regular-text code" placeholder="Paste your new API key here..." />
                                <p class="description">Enter the 32-character API key from your dashboard</p>
                            </td>
                        </tr>
                    </table>
                    <button type="submit" name="update_api_key" class="button button-secondary">
                        Update API Key
                    </button>
                </form>
            </div>
            
            <div class="card" style="max-width: none;">
                <h2>API Key Sync - Important Information</h2>
                <div style="background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 4px;">
                    <h4 style="margin-top: 0; color: #856404;">🔄 Two-Way Sync Support</h4>
                    <ul style="margin: 10px 0;">
                        <li><strong>WordPress → Dashboard:</strong> Generate new key here, then copy to your dashboard</li>
                        <li><strong>Dashboard → WordPress:</strong> Generate key in dashboard, then paste it in the "Update API Key Manually" section above</li>
                    </ul>
                    <p style="margin-bottom: 0; font-style: italic;">Both methods ensure your WordPress plugin and dashboard stay synchronized.</p>
                </div>
            </div>
            
            <div class="card" style="max-width: none;">
                <h2>Plugin Information</h2>
                <table class="widefat">
                    <tbody>
                        <tr>
                            <td><strong>Plugin Version</strong></td>
                            <td><?php echo esc_html($this->version); ?> (API Key Sync Fixed)</td>
                        </tr>
                        <tr>
                            <td><strong>WordPress Version</strong></td>
                            <td><?php echo esc_html(get_bloginfo('version')); ?></td>
                        </tr>
                        <tr>
                            <td><strong>PHP Version</strong></td>
                            <td><?php echo esc_html(phpversion()); ?></td>
                        </tr>
                        <tr>
                            <td><strong>API Namespace</strong></td>
                            <td><?php echo esc_html($this->api_namespace); ?></td>
                        </tr>
                        <tr>
                            <td><strong>API Key Length</strong></td>
                            <td><?php echo strlen($current_key); ?> characters (Fixed to 32)</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="card" style="max-width: none;">
                <h2>Available REST API Endpoints</h2>
                <p>All endpoints require the API key in the <code>X-WRM-API-Key</code> header.</p>
                
                <h3>Core Information</h3>
                <ul>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/status</code> - Site status and information</li>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/health</code> - Health check (no auth required)</li>
                </ul>
                
                <h3>Updates Management</h3>
                <ul>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/updates</code> - Available updates</li>
                    <li><code>POST <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/updates/perform</code> - Perform updates</li>
                </ul>
                
                <h3>Enhanced User Management</h3>
                <ul>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/users</code> - <strong>Users with email addresses</strong></li>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/users/detailed</code> - Detailed user information</li>
                </ul>
                
                <h3>Plugin & Theme Management</h3>
                <ul>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/plugins</code> - All plugins</li>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/themes</code> - All themes</li>
                    <li><code>POST <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/plugins/activate</code> - Activate plugin</li>
                    <li><code>POST <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/themes/activate</code> - Activate theme</li>
                </ul>
                
                <h3>Maintenance & Backup</h3>
                <ul>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/maintenance/status</code> - Maintenance mode status</li>
                    <li><code>POST <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/maintenance/enable</code> - Enable maintenance mode</li>
                    <li><code>POST <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/maintenance/disable</code> - Disable maintenance mode</li>
                    <li><code>GET <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/backup/status</code> - Backup system status</li>
                </ul>
                
                <h3>API Key Management</h3>
                <ul>
                    <li><code>POST <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/api-key/regenerate</code> - Regenerate API key via API</li>
                </ul>
            </div>
            
            <div class="card" style="max-width: none;">
                <h2>New Features in v3.2.0 (API Key Sync Fixed)</h2>
                <ul style="list-style-type: disc; margin-left: 20px;">
                    <li><strong>🔧 API Key Sync Fix</strong> - Two-way synchronization between WordPress and dashboard</li>
                    <li><strong>Enhanced User Management</strong> - User email addresses are now included in API responses</li>
                    <li><strong>Comprehensive Plugin Management</strong> - Full plugin activation, deactivation, and update capabilities</li>
                    <li><strong>Theme Management</strong> - Complete theme management including activation</li>
                    <li><strong>Maintenance Mode Control</strong> - Remote enable/disable maintenance mode</li>
                    <li><strong>Backup Integration</strong> - UpdraftPlus backup status monitoring</li>
                    <li><strong>Enhanced Security</strong> - Improved API key validation and user capability checks</li>
                    <li><strong>Better Update Management</strong> - Fixed WordPress core update detection</li>
                    <li><strong>Login Tracking</strong> - Track user login times and counts</li>
                    <li><strong>REST API Key Management</strong> - Regenerate keys via API endpoint</li>
                </ul>
            </div>
            
            <div class="card" style="max-width: none;">
                <h2>Quick Test</h2>
                <p>Test your API connection using curl:</p>
                <pre><code>curl -H "X-WRM-API-Key: <?php echo esc_html(substr($current_key, 0, 8)); ?>..." <?php echo esc_html($site_url); ?>/wp-json/<?php echo esc_html($this->api_namespace); ?>/health</code></pre>
                
                <p><strong>Security Note:</strong> Keep your API key secure. Never share it in public or unsecured channels.</p>
            </div>
        </div>
        <?php
    }
    
    // Additional helper methods for plugin/theme management
    private function update_wordpress_core() {
        // Implementation for WordPress core updates
        return array('type' => 'wordpress', 'status' => 'completed', 'message' => 'WordPress core updated');
    }
    
    private function update_plugin($plugin_file) {
        // Implementation for plugin updates
        return array('type' => 'plugin', 'item' => $plugin_file, 'status' => 'completed', 'message' => 'Plugin updated');
    }
    
    private function update_theme($theme_slug) {
        // Implementation for theme updates
        return array('type' => 'theme', 'item' => $theme_slug, 'status' => 'completed', 'message' => 'Theme updated');
    }
    
    public function activate_plugin_endpoint($request) {
        $plugin = sanitize_text_field($request->get_param('plugin'));
        if (empty($plugin)) {
            return new WP_Error('missing_plugin', 'Plugin parameter is required', array('status' => 400));
        }
        
        $result = activate_plugin($plugin);
        if (is_wp_error($result)) {
            return $result;
        }
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Plugin activated successfully',
            'plugin' => $plugin
        ));
    }
    
    public function deactivate_plugin_endpoint($request) {
        $plugin = sanitize_text_field($request->get_param('plugin'));
        if (empty($plugin)) {
            return new WP_Error('missing_plugin', 'Plugin parameter is required', array('status' => 400));
        }
        
        deactivate_plugins($plugin);
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Plugin deactivated successfully',
            'plugin' => $plugin
        ));
    }
    
    public function activate_theme_endpoint($request) {
        $theme = sanitize_text_field($request->get_param('theme'));
        if (empty($theme)) {
            return new WP_Error('missing_theme', 'Theme parameter is required', array('status' => 400));
        }
        
        switch_theme($theme);
        
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Theme activated successfully',
            'theme' => $theme
        ));
    }
}

// Initialize the plugin
new WP_Remote_Manager_Enhanced_Users();