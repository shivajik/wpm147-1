=== WP Remote Manager Secure ===
Version: 3.0.0
Requires at least: WordPress 5.0
Tested up to: 6.8
Requires PHP: 7.4
License: GPLv2 or later

Enterprise Security Edition - WordPress Remote Manager for site monitoring and management.

SECURITY FEATURES:
✅ CSRF Protection with WordPress nonces
✅ Rate Limiting (60 requests/minute)
✅ Secure API key generation
✅ Comprehensive audit logging
✅ Enhanced input validation
✅ Limited information disclosure

INSTALLATION:
1. Upload wp-remote-manager-secure.php to /wp-content/plugins/
2. Activate plugin in WordPress admin
3. Go to Settings → Remote Manager Secure
4. Generate new API key
5. Copy API key to your dashboard

CHANGELOG:
v3.0.0 - Enterprise Security Edition with enhanced protection
v2.2.0 - Added backup functionality
v2.1.0 - Initial release
