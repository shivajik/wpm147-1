import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Globe, Shield, Database, Cpu, HardDrive, Clock } from 'lucide-react';
import { SiteStatus } from '../services/wpRemoteManager';

interface SiteOverviewProps {
  status: SiteStatus;
}

export function SiteOverview({ status }: SiteOverviewProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Site Information */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Site Information</CardTitle>
          <Globe className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">URL:</span>
              <a 
                href={status.site_url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-sm text-blue-600 hover:underline"
              >
                {status.site_url.replace('https://', '')}
              </a>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">SSL:</span>
              <Badge variant={status.ssl_enabled ? 'success' : 'error'}>
                {status.ssl_enabled ? 'Enabled' : 'Disabled'}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Multisite:</span>
              <Badge variant={status.multisite ? 'default' : 'secondary'}>
                {status.multisite ? 'Yes' : 'No'}
              </Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Maintenance:</span>
              <Badge variant={status.maintenance_mode ? 'warning' : 'success'}>
                {status.maintenance_mode ? 'Active' : 'Inactive'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Versions */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">System Versions</CardTitle>
          <Cpu className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">WordPress:</span>
              <span className="text-sm font-medium">{status.wordpress_version}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">PHP:</span>
              <span className="text-sm font-medium">{status.php_version}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">MySQL:</span>
              <span className="text-sm font-medium">{status.mysql_version}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Theme:</span>
              <span className="text-sm font-medium">{status.theme.name}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Resource Usage */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Resource Usage</CardTitle>
          <HardDrive className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {status.disk_usage && (
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-600">Disk Usage:</span>
                  <span className="font-medium">{status.disk_usage.percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${status.disk_usage.percentage}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Used: {status.disk_usage.used}</span>
                  <span>Total: {status.disk_usage.total}</span>
                </div>
              </div>
            )}
            
            {status.memory_usage && (
              <div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Memory Limit:</span>
                  <span className="font-medium">{status.memory_usage.limit}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Current Usage:</span>
                  <span className="font-medium">{status.memory_usage.current}</span>
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}