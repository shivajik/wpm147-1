import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { HealthScore } from './HealthScore';
import { HealthData } from '../services/wpRemoteManager';
import { Shield, Database, Cpu, Zap, AlertTriangle } from 'lucide-react';

interface HealthDashboardProps {
  health: HealthData;
}

export function HealthDashboard({ health }: HealthDashboardProps) {
  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'good': return 'success';
      case 'warning': return 'warning';
      case 'critical': return 'error';
      default: return 'secondary';
    }
  };

  const getIcon = (category: string) => {
    switch (category) {
      case 'security': return Shield;
      case 'database': return Database;
      case 'php': return Cpu;
      case 'performance': return Zap;
      default: return AlertTriangle;
    }
  };

  const categories = [
    { key: 'wordpress', label: 'WordPress', data: health.wordpress },
    { key: 'php', label: 'PHP', data: health.php },
    { key: 'database', label: 'Database', data: health.database },
    { key: 'security', label: 'Security', data: health.security },
    { key: 'performance', label: 'Performance', data: health.performance },
  ];

  return (
    <div className="space-y-6">
      {/* Overall Health Score */}
      <Card>
        <CardHeader>
          <CardTitle className="text-center">Overall Site Health</CardTitle>
        </CardHeader>
        <CardContent className="flex justify-center">
          <HealthScore score={health.overall_score} size="lg" />
        </CardContent>
      </Card>

      {/* Health Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {categories.map(({ key, label, data }) => {
          const Icon = getIcon(key);
          return (
            <Card key={key}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{label}</CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-3">
                  <HealthScore score={data.score} size="sm" />
                  <Badge variant={getStatusVariant(data.status)}>
                    {data.status.charAt(0).toUpperCase() + data.status.slice(1)}
                  </Badge>
                </div>
                
                {data.issues && data.issues.length > 0 && (
                  <div className="space-y-1">
                    <h4 className="text-xs font-medium text-gray-700">Issues:</h4>
                    <ul className="text-xs text-gray-600 space-y-1">
                      {data.issues.slice(0, 3).map((issue, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-red-500 mr-1">•</span>
                          {issue}
                        </li>
                      ))}
                      {data.issues.length > 3 && (
                        <li className="text-gray-500">
                          +{data.issues.length - 3} more issues
                        </li>
                      )}
                    </ul>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Last Check */}
      <div className="text-center text-sm text-gray-500">
        Last health check: {new Date(health.last_check).toLocaleString()}
      </div>
    </div>
  );
}