import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { UpdateInfo } from '../services/wpRemoteManager';
import { Download, AlertCircle, CheckCircle } from 'lucide-react';

interface UpdatesPanelProps {
  updates: UpdateInfo;
  onRefresh: () => void;
  loading?: boolean;
}

export function UpdatesPanel({ updates, onRefresh, loading }: UpdatesPanelProps) {
  const totalUpdates = 
    (updates.wordpress.update_available ? 1 : 0) +
    updates.plugins.length +
    updates.themes.length;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-lg font-semibold">Available Updates</CardTitle>
        <div className="flex items-center space-x-2">
          {totalUpdates > 0 ? (
            <Badge variant="warning" className="flex items-center space-x-1">
              <AlertCircle className="h-3 w-3" />
              <span>{totalUpdates} updates</span>
            </Badge>
          ) : (
            <Badge variant="success" className="flex items-center space-x-1">
              <CheckCircle className="h-3 w-3" />
              <span>Up to date</span>
            </Badge>
          )}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onRefresh}
            disabled={loading}
          >
            {loading ? 'Checking...' : 'Refresh'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* WordPress Core Update */}
        {updates.wordpress.update_available && (
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">WordPress Core</h3>
                <p className="text-sm text-gray-600">
                  {updates.wordpress.current_version} → {updates.wordpress.new_version}
                </p>
              </div>
              <Badge variant="warning">
                <Download className="h-3 w-3 mr-1" />
                Update Available
              </Badge>
            </div>
          </div>
        )}

        {/* Plugin Updates */}
        {updates.plugins.length > 0 && (
          <div className="space-y-2">
            <h3 className="font-medium text-sm text-gray-700">
              Plugin Updates ({updates.plugins.length})
            </h3>
            <div className="space-y-2">
              {updates.plugins.map((plugin, index) => (
                <div key={index} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-sm">{plugin.name}</h4>
                      <p className="text-xs text-gray-600">
                        {plugin.current_version} → {plugin.new_version}
                      </p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      Plugin
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Theme Updates */}
        {updates.themes.length > 0 && (
          <div className="space-y-2">
            <h3 className="font-medium text-sm text-gray-700">
              Theme Updates ({updates.themes.length})
            </h3>
            <div className="space-y-2">
              {updates.themes.map((theme, index) => (
                <div key={index} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-sm">{theme.name}</h4>
                      <p className="text-xs text-gray-600">
                        {theme.current_version} → {theme.new_version}
                      </p>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      Theme
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {totalUpdates === 0 && (
          <div className="text-center py-8 text-gray-500">
            <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-500" />
            <p>All components are up to date!</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}