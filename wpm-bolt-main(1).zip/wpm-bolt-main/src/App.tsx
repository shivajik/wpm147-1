import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { Badge } from './components/ui/badge';
import { SiteOverview } from './components/SiteOverview';
import { HealthDashboard } from './components/HealthDashboard';
import { UpdatesPanel } from './components/UpdatesPanel';
import { wpRemoteManager, SiteStatus, HealthData, UpdateInfo } from './services/wpRemoteManager';
import { RefreshCw, Server, Activity, Download, Settings, AlertTriangle } from 'lucide-react';

function App() {
  const [siteStatus, setSiteStatus] = useState<SiteStatus | null>(null);
  const [healthData, setHealthData] = useState<HealthData | null>(null);
  const [updateInfo, setUpdateInfo] = useState<UpdateInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'health' | 'updates'>('overview');

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [status, health, updates] = await Promise.all([
        wpRemoteManager.getSiteStatus(),
        wpRemoteManager.getHealthData(),
        wpRemoteManager.getUpdates(),
      ]);
      
      setSiteStatus(status);
      setHealthData(health);
      setUpdateInfo(updates);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const toggleMaintenance = async () => {
    if (!siteStatus) return;
    
    try {
      await wpRemoteManager.toggleMaintenanceMode(!siteStatus.maintenance_mode);
      await fetchData(); // Refresh data
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to toggle maintenance mode');
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4 text-blue-600" />
          <p className="text-gray-600">Loading site data...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center text-red-600">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Connection Error
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">{error}</p>
            <Button onClick={fetchData} className="w-full">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry Connection
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Server className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-xl font-semibold text-gray-900">
                  WordPress Remote Manager
                </h1>
                <p className="text-sm text-gray-500">
                  {siteStatus?.site_url.replace('https://', '')}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant={siteStatus?.maintenance_mode ? "destructive" : "outline"}
                size="sm"
                onClick={toggleMaintenance}
              >
                <Settings className="h-4 w-4 mr-2" />
                {siteStatus?.maintenance_mode ? 'Disable' : 'Enable'} Maintenance
              </Button>
              <Button variant="outline" size="sm" onClick={fetchData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'overview'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Server className="h-4 w-4 inline mr-2" />
              Site Overview
            </button>
            <button
              onClick={() => setActiveTab('health')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'health'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Activity className="h-4 w-4 inline mr-2" />
              Site Health
            </button>
            <button
              onClick={() => setActiveTab('updates')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'updates'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Download className="h-4 w-4 inline mr-2" />
              Updates
              {updateInfo && (
                (updateInfo.wordpress.update_available ? 1 : 0) +
                updateInfo.plugins.length +
                updateInfo.themes.length
              ) > 0 && (
                <Badge variant="warning" className="ml-2 text-xs">
                  {(updateInfo.wordpress.update_available ? 1 : 0) +
                   updateInfo.plugins.length +
                   updateInfo.themes.length}
                </Badge>
              )}
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'overview' && siteStatus && (
          <SiteOverview status={siteStatus} />
        )}
        
        {activeTab === 'health' && healthData && (
          <HealthDashboard health={healthData} />
        )}
        
        {activeTab === 'updates' && updateInfo && (
          <UpdatesPanel 
            updates={updateInfo} 
            onRefresh={fetchData}
            loading={loading}
          />
        )}
      </main>
    </div>
  );
}

export default App;