const SITE_URL = 'https://ascollegechincholi.com';
const API_KEY = 'D3gGZf4gvT6CHUtaUsggCd6GTJolfwV0';
const API_BASE = `${SITE_URL}/wp-json/wrm/v1`;

interface SiteStatus {
  site_url: string;
  admin_email: string;
  wordpress_version: string;
  php_version: string;
  mysql_version: string;
  theme: {
    name: string;
    version: string;
  };
  plugins: Array<{
    name: string;
    version: string;
    active: boolean;
  }>;
  maintenance_mode: boolean;
  disk_usage: {
    used: string;
    free: string;
    total: string;
    percentage: number;
  };
  memory_usage: {
    current: string;
    peak: string;
    limit: string;
  };
  ssl_enabled: boolean;
  multisite: boolean;
  timestamp: string;
}

interface HealthData {
  overall_score: number;
  wordpress: {
    score: number;
    status: string;
    version: string;
    issues: string[];
  };
  php: {
    score: number;
    status: string;
    version: string;
    memory_limit: string;
    issues: string[];
  };
  database: {
    score: number;
    status: string;
    version: string;
    issues: string[];
  };
  security: {
    score: number;
    status: string;
    ssl_enabled: boolean;
    issues: string[];
  };
  performance: {
    score: number;
    status: string;
    object_cache_enabled: boolean;
    issues: string[];
  };
  last_check: string;
}

interface UpdateInfo {
  wordpress: {
    current_version?: string;
    new_version?: string;
    update_available: boolean;
  };
  plugins: Array<{
    plugin: string;
    name: string;
    current_version: string;
    new_version: string;
  }>;
  themes: Array<{
    theme: string;
    name: string;
    current_version: string;
    new_version: string;
  }>;
}

class WPRemoteManagerService {
  private async makeRequest<T>(endpoint: string): Promise<T> {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      headers: {
        'X-WRM-API-Key': API_KEY,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async getSiteStatus(): Promise<SiteStatus> {
    return this.makeRequest<SiteStatus>('/status');
  }

  async getHealthData(): Promise<HealthData> {
    return this.makeRequest<HealthData>('/health');
  }

  async getUpdates(): Promise<UpdateInfo> {
    return this.makeRequest<UpdateInfo>('/updates');
  }

  async toggleMaintenanceMode(enable?: boolean): Promise<{ maintenance_mode: boolean; message: string }> {
    const response = await fetch(`${API_BASE}/maintenance`, {
      method: 'POST',
      headers: {
        'X-WRM-API-Key': API_KEY,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(enable !== undefined ? { enable } : {}),
    });

    if (!response.ok) {
      throw new Error(`Failed to toggle maintenance mode: ${response.status}`);
    }

    return response.json();
  }
}

export const wpRemoteManager = new WPRemoteManagerService();
export type { SiteStatus, HealthData, UpdateInfo };