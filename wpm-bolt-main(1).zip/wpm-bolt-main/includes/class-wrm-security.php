<?php
/**
 * Security and authentication class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WRM_Security {
    
    /**
     * Authenticate API request
     */
    public function authenticate_request($request) {
        // Check API key
        $api_key = $this->get_api_key_from_request($request);
        if (!$this->validate_api_key($api_key)) {
            return new WP_Error('invalid_api_key', __('Invalid API key', 'wp-remote-manager'), array('status' => 401));
        }
        
        // Check IP whitelist
        if (!$this->validate_ip_address()) {
            return new WP_Error('ip_not_allowed', __('IP address not allowed', 'wp-remote-manager'), array('status' => 403));
        }
        
        // Rate limiting
        if (!$this->check_rate_limit()) {
            return new WP_Error('rate_limit_exceeded', __('Rate limit exceeded', 'wp-remote-manager'), array('status' => 429));
        }
        
        return true;
    }
    
    /**
     * Get API key from request
     */
    private function get_api_key_from_request($request) {
        // Check header first
        $api_key = $request->get_header('X-WRM-API-Key');
        
        // Fallback to Authorization header
        if (empty($api_key)) {
            $auth_header = $request->get_header('Authorization');
            if ($auth_header && strpos($auth_header, 'Bearer ') === 0) {
                $api_key = substr($auth_header, 7);
            }
        }
        
        // Fallback to query parameter (not recommended for production)
        if (empty($api_key)) {
            $api_key = $request->get_param('api_key');
        }
        
        return $api_key;
    }
    
    /**
     * Validate API key
     */
    private function validate_api_key($provided_key) {
        if (empty($provided_key)) {
            return false;
        }
        
        $stored_key = get_option('wrm_api_key');
        if (empty($stored_key)) {
            return false;
        }
        
        return hash_equals($stored_key, $provided_key);
    }
    
    /**
     * Validate IP address
     */
    private function validate_ip_address() {
        $allowed_ips = get_option('wrm_allowed_ips', array());
        
        // If no IP restrictions are set, allow all
        if (empty($allowed_ips)) {
            return true;
        }
        
        $client_ip = $this->get_client_ip();
        
        foreach ($allowed_ips as $allowed_ip) {
            if ($this->ip_in_range($client_ip, trim($allowed_ip))) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check rate limit
     */
    private function check_rate_limit() {
        $client_ip = $this->get_client_ip();
        $rate_limit_key = 'wrm_rate_limit_' . md5($client_ip);
        
        $requests = get_transient($rate_limit_key);
        if ($requests === false) {
            $requests = 0;
        }
        
        // Allow 60 requests per minute
        if ($requests >= 60) {
            return false;
        }
        
        $requests++;
        set_transient($rate_limit_key, $requests, 60);
        
        return true;
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    
    /**
     * Check if IP is in range
     */
    private function ip_in_range($ip, $range) {
        if (strpos($range, '/') === false) {
            // Single IP
            return $ip === $range;
        }
        
        // CIDR range
        list($subnet, $bits) = explode('/', $range, 2);
        
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return $this->ipv4_in_range($ip, $subnet, $bits);
        } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            return $this->ipv6_in_range($ip, $subnet, $bits);
        }
        
        return false;
    }
    
    /**
     * Check if IPv4 is in range
     */
    private function ipv4_in_range($ip, $subnet, $bits) {
        $ip = ip2long($ip);
        $subnet = ip2long($subnet);
        $mask = -1 << (32 - $bits);
        $subnet &= $mask;
        
        return ($ip & $mask) === $subnet;
    }
    
    /**
     * Check if IPv6 is in range
     */
    private function ipv6_in_range($ip, $subnet, $bits) {
        $subnet = inet_pton($subnet);
        $ip = inet_pton($ip);
        
        $bytes_addr = unpack('n*', $subnet);
        $bytes_test = unpack('n*', $ip);
        
        for ($i = 1, $ceil = ceil($bits / 16); $i <= $ceil; ++$i) {
            $left = $bits - 16 * ($i - 1);
            $left = ($left <= 16) ? $left : 16;
            $mask = ~(0xffff >> $left) & 0xffff;
            
            if (($bytes_addr[$i] & $mask) !== ($bytes_test[$i] & $mask)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Generate secure API key
     */
    public function generate_api_key() {
        return wp_generate_password(32, false);
    }
    
    /**
     * Hash sensitive data
     */
    public function hash_data($data) {
        return wp_hash($data);
    }
    
    /**
     * Sanitize IP address input
     */
    public function sanitize_ip_input($input) {
        $lines = explode("\n", $input);
        $cleaned = array();
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }
            
            // Validate IP or CIDR
            if (filter_var($line, FILTER_VALIDATE_IP) || $this->validate_cidr($line)) {
                $cleaned[] = $line;
            }
        }
        
        return implode("\n", $cleaned);
    }
    
    /**
     * Validate CIDR notation
     */
    private function validate_cidr($cidr) {
        if (strpos($cidr, '/') === false) {
            return false;
        }
        
        list($ip, $bits) = explode('/', $cidr, 2);
        
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            return false;
        }
        
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
            return $bits >= 0 && $bits <= 32;
        } elseif (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
            return $bits >= 0 && $bits <= 128;
        }
        
        return false;
    }
}