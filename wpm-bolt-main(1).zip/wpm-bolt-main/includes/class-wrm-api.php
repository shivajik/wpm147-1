<?php
/**
 * REST API class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WRM_API {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_action('init', array($this, 'handle_maintenance_mode'));
    }
    
    /**
     * Register REST API routes
     */
    public function register_routes() {
        register_rest_route('wrm/v1', '/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_status'),
            'permission_callback' => array($this, 'check_permissions')
        ));
        
        register_rest_route('wrm/v1', '/updates', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_updates'),
            'permission_callback' => array($this, 'check_permissions')
        ));
        
        register_rest_route('wrm/v1', '/updates/(?P<type>wordpress|plugins|themes)', array(
            'methods' => 'POST',
            'callback' => array($this, 'perform_updates'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'type' => array(
                    'required' => true,
                    'enum' => array('wordpress', 'plugins', 'themes')
                )
            )
        ));
        
        register_rest_route('wrm/v1', '/backup', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_backup'),
            'permission_callback' => array($this, 'check_permissions')
        ));
        
        register_rest_route('wrm/v1', '/maintenance', array(
            'methods' => 'POST',
            'callback' => array($this, 'toggle_maintenance'),
            'permission_callback' => array($this, 'check_permissions')
        ));
        
        register_rest_route('wrm/v1', '/health', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_health'),
            'permission_callback' => array($this, 'check_permissions')
        ));
        
        register_rest_route('wrm/v1', '/logs', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_logs'),
            'permission_callback' => array($this, 'check_permissions')
        ));
    }
    
    /**
     * Check API permissions
     */
    public function check_permissions($request) {
        $security = new WRM_Security();
        return $security->authenticate_request($request);
    }
    
    /**
     * Get site status
     */
    public function get_status($request) {
        do_action('wrm_before_api_call', 'status', $request);
        
        global $wp_version;
        
        $status = array(
            'site_url' => home_url(),
            'admin_email' => get_option('admin_email'),
            'wordpress_version' => $wp_version,
            'php_version' => PHP_VERSION,
            'mysql_version' => $this->get_mysql_version(),
            'theme' => array(
                'name' => wp_get_theme()->get('Name'),
                'version' => wp_get_theme()->get('Version')
            ),
            'plugins' => $this->get_plugin_info(),
            'maintenance_mode' => get_option('wrm_maintenance_mode', false),
            'last_update_check' => get_option('_transient_update_core'),
            'disk_usage' => $this->get_disk_usage(),
            'memory_usage' => $this->get_memory_usage(),
            'ssl_enabled' => is_ssl(),
            'multisite' => is_multisite(),
            'timestamp' => current_time('mysql')
        );
        
        WP_Remote_Manager::log_activity('api_status_check', 'Site status retrieved via API');
        
        do_action('wrm_after_api_call', 'status', $request, $status);
        
        return rest_ensure_response($status);
    }
    
    /**
     * Get available updates
     */
    public function get_updates($request) {
        do_action('wrm_before_api_call', 'updates', $request);
        
        // Force update checks
        wp_update_plugins();
        wp_update_themes();
        wp_version_check();
        
        $updates = array(
            'wordpress' => $this->get_wordpress_updates(),
            'plugins' => $this->get_plugin_updates(),
            'themes' => $this->get_theme_updates()
        );
        
        WP_Remote_Manager::log_activity('api_updates_check', 'Available updates retrieved via API');
        
        do_action('wrm_after_api_call', 'updates', $request, $updates);
        
        return rest_ensure_response($updates);
    }
    
    /**
     * Perform updates
     */
    public function perform_updates($request) {
        do_action('wrm_before_api_call', 'perform_updates', $request);
        
        $type = $request->get_param('type');
        $items = $request->get_param('items');
        
        $results = array();
        
        switch ($type) {
            case 'wordpress':
                $results = $this->update_wordpress();
                break;
            case 'plugins':
                $results = $this->update_plugins($items);
                break;
            case 'themes':
                $results = $this->update_themes($items);
                break;
        }
        
        WP_Remote_Manager::log_activity('api_updates_performed', "Updates performed: {$type}", !empty($results['errors']) ? 'error' : 'success');
        
        do_action('wrm_after_api_call', 'perform_updates', $request, $results);
        
        return rest_ensure_response($results);
    }
    
    /**
     * Create backup
     */
    public function create_backup($request) {
        do_action('wrm_before_api_call', 'backup', $request);
        
        $backup = new WRM_Backup();
        $result = $backup->create_backup();
        
        $status = $result['success'] ? 'success' : 'error';
        WP_Remote_Manager::log_activity('api_backup_created', $result['message'], $status);
        
        do_action('wrm_after_api_call', 'backup', $request, $result);
        
        return rest_ensure_response($result);
    }
    
    /**
     * Toggle maintenance mode
     */
    public function toggle_maintenance($request) {
        do_action('wrm_before_api_call', 'maintenance', $request);
        
        $enable = $request->get_param('enable');
        $current_mode = get_option('wrm_maintenance_mode', false);
        
        if ($enable !== null) {
            $new_mode = (bool) $enable;
        } else {
            $new_mode = !$current_mode;
        }
        
        update_option('wrm_maintenance_mode', $new_mode);
        
        $result = array(
            'maintenance_mode' => $new_mode,
            'message' => $new_mode ? 
                __('Maintenance mode enabled', 'wp-remote-manager') : 
                __('Maintenance mode disabled', 'wp-remote-manager')
        );
        
        $status = $new_mode ? 'enabled' : 'disabled';
        WP_Remote_Manager::log_activity('api_maintenance_toggled', "Maintenance mode {$status} via API");
        
        do_action('wrm_after_api_call', 'maintenance', $request, $result);
        
        return rest_ensure_response($result);
    }
    
    /**
     * Get site health
     */
    public function get_health($request) {
        do_action('wrm_before_api_call', 'health', $request);
        
        $site_health = new WRM_Site_Health();
        $health_data = $site_health->get_site_health();
        
        WP_Remote_Manager::log_activity('api_health_check', 'Site health data retrieved via API');
        
        do_action('wrm_after_api_call', 'health', $request, $health_data);
        
        return rest_ensure_response($health_data);
    }
    
    /**
     * Get activity logs
     */
    public function get_logs($request) {
        do_action('wrm_before_api_call', 'logs', $request);
        
        $database = new WRM_Database();
        $limit = $request->get_param('limit') ?: 50;
        $offset = $request->get_param('offset') ?: 0;
        
        $logs = $database->get_logs($limit, $offset);
        
        WP_Remote_Manager::log_activity('api_logs_retrieved', 'Activity logs retrieved via API');
        
        do_action('wrm_after_api_call', 'logs', $request, $logs);
        
        return rest_ensure_response($logs);
    }
    
    /**
     * Handle maintenance mode
     */
    public function handle_maintenance_mode() {
        if (!get_option('wrm_maintenance_mode', false)) {
            return;
        }
        
        // Skip for admin users and API requests
        if (current_user_can('administrator') || strpos($_SERVER['REQUEST_URI'] ?? '', '/wp-json/wrm/') !== false) {
            return;
        }
        
        // Skip for login page
        if (in_array($GLOBALS['pagenow'], array('wp-login.php', 'wp-register.php'))) {
            return;
        }
        
        // Show maintenance page
        wp_die($this->get_maintenance_page(), __('Site Under Maintenance', 'wp-remote-manager'), array('response' => 503));
    }
    
    /**
     * Get maintenance page HTML
     */
    private function get_maintenance_page() {
        ob_start();
        ?>
        <!DOCTYPE html>
        <html <?php language_attributes(); ?>>
        <head>
            <meta charset="<?php bloginfo('charset'); ?>">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <title><?php _e('Site Under Maintenance', 'wp-remote-manager'); ?> - <?php bloginfo('name'); ?></title>
            <style>
                body { 
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: #fff;
                    margin: 0;
                    padding: 0;
                    min-height: 100vh;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                }
                .maintenance-container {
                    text-align: center;
                    max-width: 500px;
                    padding: 2rem;
                    background: rgba(255, 255, 255, 0.1);
                    border-radius: 10px;
                    backdrop-filter: blur(10px);
                }
                .maintenance-container h1 {
                    font-size: 2.5rem;
                    margin-bottom: 1rem;
                }
                .maintenance-container p {
                    font-size: 1.1rem;
                    line-height: 1.6;
                    margin-bottom: 1.5rem;
                }
            </style>
        </head>
        <body>
            <div class="maintenance-container">
                <h1><?php _e('Site Under Maintenance', 'wp-remote-manager'); ?></h1>
                <p><?php _e('We are currently performing scheduled maintenance. We should be back online shortly.', 'wp-remote-manager'); ?></p>
                <p><?php _e('Thank you for your patience.', 'wp-remote-manager'); ?></p>
            </div>
        </body>
        </html>
        <?php
        return ob_get_clean();
    }
    
    // Helper methods for getting system information
    
    private function get_mysql_version() {
        global $wpdb;
        return $wpdb->get_var("SELECT VERSION()");
    }
    
    private function get_plugin_info() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        
        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins');
        
        $plugin_info = array();
        foreach ($plugins as $plugin_file => $plugin_data) {
            $plugin_info[] = array(
                'name' => $plugin_data['Name'],
                'version' => $plugin_data['Version'],
                'active' => in_array($plugin_file, $active_plugins)
            );
        }
        
        return $plugin_info;
    }
    
    private function get_disk_usage() {
        $upload_dir = wp_upload_dir();
        $size = 0;
        
        if (function_exists('disk_free_space') && function_exists('disk_total_space')) {
            $free = disk_free_space($upload_dir['basedir']);
            $total = disk_total_space($upload_dir['basedir']);
            
            if ($free !== false && $total !== false) {
                $used = $total - $free;
                $size = array(
                    'used' => size_format($used),
                    'free' => size_format($free),
                    'total' => size_format($total),
                    'percentage' => round(($used / $total) * 100, 2)
                );
            }
        }
        
        return $size;
    }
    
    private function get_memory_usage() {
        return array(
            'current' => size_format(memory_get_usage(true)),
            'peak' => size_format(memory_get_peak_usage(true)),
            'limit' => ini_get('memory_limit')
        );
    }
    
    private function get_wordpress_updates() {
        $updates = get_core_updates();
        if (empty($updates) || $updates[0]->response === 'latest') {
            return array();
        }
        
        return array(
            'current_version' => get_bloginfo('version'),
            'new_version' => $updates[0]->version,
            'update_available' => true
        );
    }
    
    private function get_plugin_updates() {
        $updates = get_plugin_updates();
        $plugin_updates = array();
        
        foreach ($updates as $plugin_file => $plugin_data) {
            $plugin_updates[] = array(
                'plugin' => $plugin_file,
                'name' => $plugin_data->Name,
                'current_version' => $plugin_data->Version,
                'new_version' => $plugin_data->update->new_version
            );
        }
        
        return $plugin_updates;
    }
    
    private function get_theme_updates() {
        $updates = get_theme_updates();
        $theme_updates = array();
        
        foreach ($updates as $theme_key => $theme_data) {
            $theme_updates[] = array(
                'theme' => $theme_key,
                'name' => $theme_data->get('Name'),
                'current_version' => $theme_data->get('Version'),
                'new_version' => $theme_data->update['new_version']
            );
        }
        
        return $theme_updates;
    }
    
    private function update_wordpress() {
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        include_once ABSPATH . 'wp-admin/includes/upgrade.php';
        
        $upgrader = new Core_Upgrader();
        $result = $upgrader->upgrade(get_bloginfo('version'));
        
        return array(
            'success' => !is_wp_error($result),
            'message' => is_wp_error($result) ? $result->get_error_message() : __('WordPress updated successfully', 'wp-remote-manager')
        );
    }
    
    private function update_plugins($plugins = null) {
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        
        $upgrader = new Plugin_Upgrader();
        $results = array();
        
        if (empty($plugins)) {
            $plugins = array_keys(get_plugin_updates());
        }
        
        foreach ($plugins as $plugin) {
            $result = $upgrader->upgrade($plugin);
            $results[] = array(
                'plugin' => $plugin,
                'success' => !is_wp_error($result),
                'message' => is_wp_error($result) ? $result->get_error_message() : __('Plugin updated successfully', 'wp-remote-manager')
            );
        }
        
        return $results;
    }
    
    private function update_themes($themes = null) {
        include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        
        $upgrader = new Theme_Upgrader();
        $results = array();
        
        if (empty($themes)) {
            $themes = array_keys(get_theme_updates());
        }
        
        foreach ($themes as $theme) {
            $result = $upgrader->upgrade($theme);
            $results[] = array(
                'theme' => $theme,
                'success' => !is_wp_error($result),
                'message' => is_wp_error($result) ? $result->get_error_message() : __('Theme updated successfully', 'wp-remote-manager')
            );
        }
        
        return $results;
    }
}