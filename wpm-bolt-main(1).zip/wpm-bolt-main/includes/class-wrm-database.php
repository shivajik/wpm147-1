<?php
/**
 * Database operations class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WRM_Database {
    
    /**
     * Create database tables
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Activity logs table
        $logs_table = $wpdb->prefix . 'wrm_logs';
        $logs_sql = "CREATE TABLE $logs_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            action varchar(255) NOT NULL,
            details text,
            status varchar(20) DEFAULT 'success',
            ip_address varchar(45),
            user_agent text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY action (action),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        // Site health table
        $health_table = $wpdb->prefix . 'wrm_site_health';
        $health_sql = "CREATE TABLE $health_table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            metric_name varchar(100) NOT NULL,
            metric_value text,
            score int(3) DEFAULT 0,
            status varchar(20) DEFAULT 'good',
            checked_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY metric_name (metric_name),
            KEY checked_at (checked_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($logs_sql);
        dbDelta($health_sql);
    }
    
    /**
     * Log activity
     */
    public function log_activity($action, $details = '', $status = 'success') {
        global $wpdb;
        
        $table = $wpdb->prefix . 'wrm_logs';
        
        $data = array(
            'action' => sanitize_text_field($action),
            'details' => sanitize_textarea_field($details),
            'status' => sanitize_text_field($status),
            'ip_address' => $this->get_client_ip(),
            'user_agent' => substr(sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 500)
        );
        
        $wpdb->insert($table, $data);
        
        // Clean old logs
        $this->cleanup_old_logs();
    }
    
    /**
     * Get activity logs
     */
    public function get_logs($limit = 50, $offset = 0, $filters = array()) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'wrm_logs';
        $where = array('1=1');
        $params = array();
        
        if (!empty($filters['action'])) {
            $where[] = 'action = %s';
            $params[] = $filters['action'];
        }
        
        if (!empty($filters['status'])) {
            $where[] = 'status = %s';
            $params[] = $filters['status'];
        }
        
        if (!empty($filters['date_from'])) {
            $where[] = 'created_at >= %s';
            $params[] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $where[] = 'created_at <= %s';
            $params[] = $filters['date_to'];
        }
        
        $where_clause = implode(' AND ', $where);
        $params[] = (int) $limit;
        $params[] = (int) $offset;
        
        $sql = "SELECT * FROM $table WHERE $where_clause ORDER BY created_at DESC LIMIT %d OFFSET %d";
        
        if (!empty($params)) {
            $sql = $wpdb->prepare($sql, $params);
        }
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * Store site health data
     */
    public function store_health_data($metric_name, $metric_value, $score = 0, $status = 'good') {
        global $wpdb;
        
        $table = $wpdb->prefix . 'wrm_site_health';
        
        // Remove old entry for this metric
        $wpdb->delete($table, array('metric_name' => $metric_name));
        
        // Insert new data
        $data = array(
            'metric_name' => sanitize_text_field($metric_name),
            'metric_value' => sanitize_textarea_field($metric_value),
            'score' => (int) $score,
            'status' => sanitize_text_field($status)
        );
        
        return $wpdb->insert($table, $data);
    }
    
    /**
     * Get site health data
     */
    public function get_health_data() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'wrm_site_health';
        $sql = "SELECT * FROM $table ORDER BY checked_at DESC";
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * Clean up old logs
     */
    private function cleanup_old_logs() {
        global $wpdb;
        
        $retention_days = get_option('wrm_log_retention_days', 30);
        if ($retention_days <= 0) {
            return;
        }
        
        $table = $wpdb->prefix . 'wrm_logs';
        $cutoff_date = date('Y-m-d H:i:s', strtotime("-{$retention_days} days"));
        
        $wpdb->query($wpdb->prepare(
            "DELETE FROM $table WHERE created_at < %s",
            $cutoff_date
        ));
    }
    
    /**
     * Get client IP address
     */
    private function get_client_ip() {
        $ip_keys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'HTTP_CLIENT_IP', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = $_SERVER[$key];
                if (strpos($ip, ',') !== false) {
                    $ip = trim(explode(',', $ip)[0]);
                }
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
}