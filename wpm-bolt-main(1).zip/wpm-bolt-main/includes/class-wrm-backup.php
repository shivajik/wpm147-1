<?php
/**
 * Backup functionality class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WRM_Backup {
    
    private $backup_dir;
    
    /**
     * Constructor
     */
    public function __construct() {
        $upload_dir = wp_upload_dir();
        $this->backup_dir = $upload_dir['basedir'] . '/wp-remote-manager-backups';
        
        // Create backup directory if it doesn't exist
        if (!file_exists($this->backup_dir)) {
            wp_mkdir_p($this->backup_dir);
            
            // Add .htaccess to protect backup files
            $htaccess_content = "deny from all\n";
            file_put_contents($this->backup_dir . '/.htaccess', $htaccess_content);
        }
    }
    
    /**
     * Create a basic backup
     */
    public function create_backup($include_uploads = false) {
        try {
            $backup_filename = 'backup-' . date('Y-m-d-H-i-s') . '.zip';
            $backup_path = $this->backup_dir . '/' . $backup_filename;
            
            // Initialize zip archive
            if (!class_exists('ZipArchive')) {
                return array(
                    'success' => false,
                    'message' => __('ZipArchive class is not available', 'wp-remote-manager')
                );
            }
            
            $zip = new ZipArchive();
            if ($zip->open($backup_path, ZipArchive::CREATE) !== TRUE) {
                return array(
                    'success' => false,
                    'message' => __('Cannot create backup file', 'wp-remote-manager')
                );
            }
            
            // Add database dump
            $db_dump = $this->create_database_dump();
            if ($db_dump['success']) {
                $zip->addFile($db_dump['file'], 'database.sql');
            }
            
            // Add WordPress files (excluding uploads if not requested)
            $this->add_files_to_zip($zip, ABSPATH, '', $include_uploads);
            
            $zip->close();
            
            // Clean up database dump file
            if (isset($db_dump['file']) && file_exists($db_dump['file'])) {
                unlink($db_dump['file']);
            }
            
            $backup_size = filesize($backup_path);
            
            return array(
                'success' => true,
                'message' => __('Backup created successfully', 'wp-remote-manager'),
                'filename' => $backup_filename,
                'size' => size_format($backup_size),
                'path' => $backup_path,
                'created_at' => current_time('mysql')
            );
            
        } catch (Exception $e) {
            return array(
                'success' => false,
                'message' => sprintf(__('Backup failed: %s', 'wp-remote-manager'), $e->getMessage())
            );
        }
    }
    
    /**
     * Create database dump
     */
    private function create_database_dump() {
        global $wpdb;
        
        try {
            $dump_file = $this->backup_dir . '/temp_db_dump.sql';
            $handle = fopen($dump_file, 'w');
            
            if (!$handle) {
                return array('success' => false, 'message' => __('Cannot create database dump file', 'wp-remote-manager'));
            }
            
            // Get all tables
            $tables = $wpdb->get_results("SHOW TABLES", ARRAY_N);
            
            foreach ($tables as $table) {
                $table_name = $table[0];
                
                // Skip non-WordPress tables
                if (strpos($table_name, $wpdb->prefix) !== 0) {
                    continue;
                }
                
                // Get table structure
                $create_table = $wpdb->get_row("SHOW CREATE TABLE `$table_name`", ARRAY_N);
                fwrite($handle, "\n\n-- Table structure for table `$table_name`\n\n");
                fwrite($handle, "DROP TABLE IF EXISTS `$table_name`;\n");
                fwrite($handle, $create_table[1] . ";\n\n");
                
                // Get table data
                $rows = $wpdb->get_results("SELECT * FROM `$table_name`", ARRAY_A);
                
                if (!empty($rows)) {
                    fwrite($handle, "-- Dumping data for table `$table_name`\n\n");
                    
                    foreach ($rows as $row) {
                        $values = array();
                        foreach ($row as $value) {
                            if ($value === null) {
                                $values[] = 'NULL';
                            } else {
                                $values[] = "'" . $wpdb->_real_escape($value) . "'";
                            }
                        }
                        fwrite($handle, "INSERT INTO `$table_name` VALUES (" . implode(',', $values) . ");\n");
                    }
                    fwrite($handle, "\n");
                }
            }
            
            fclose($handle);
            
            return array('success' => true, 'file' => $dump_file);
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * Add files to zip archive recursively
     */
    private function add_files_to_zip($zip, $source_dir, $zip_dir = '', $include_uploads = false) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($source_dir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        foreach ($iterator as $file) {
            $file_path = $file->getRealPath();
            $relative_path = $zip_dir . substr($file_path, strlen($source_dir) + 1);
            
            // Skip certain directories and files
            if ($this->should_skip_file($file_path, $include_uploads)) {
                continue;
            }
            
            if ($file->isDir()) {
                $zip->addEmptyDir($relative_path);
            } elseif ($file->isFile()) {
                $zip->addFile($file_path, $relative_path);
            }
        }
    }
    
    /**
     * Check if file should be skipped
     */
    private function should_skip_file($file_path, $include_uploads = false) {
        $skip_patterns = array(
            '/wp-content/cache/',
            '/wp-content/backup',
            '/wp-content/wp-remote-manager-backups/',
            '/.git/',
            '/node_modules/',
            '.log',
            '.tmp'
        );
        
        if (!$include_uploads) {
            $skip_patterns[] = '/wp-content/uploads/';
        }
        
        foreach ($skip_patterns as $pattern) {
            if (strpos($file_path, $pattern) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get list of available backups
     */
    public function get_backups() {
        $backups = array();
        
        if (!is_dir($this->backup_dir)) {
            return $backups;
        }
        
        $files = glob($this->backup_dir . '/backup-*.zip');
        
        foreach ($files as $file) {
            $backups[] = array(
                'filename' => basename($file),
                'size' => size_format(filesize($file)),
                'created_at' => date('Y-m-d H:i:s', filemtime($file)),
                'path' => $file
            );
        }
        
        // Sort by creation time (newest first)
        usort($backups, function($a, $b) {
            return strcmp($b['created_at'], $a['created_at']);
        });
        
        return $backups;
    }
    
    /**
     * Delete a backup file
     */
    public function delete_backup($filename) {
        $backup_path = $this->backup_dir . '/' . basename($filename);
        
        if (!file_exists($backup_path)) {
            return array(
                'success' => false,
                'message' => __('Backup file not found', 'wp-remote-manager')
            );
        }
        
        if (unlink($backup_path)) {
            return array(
                'success' => true,
                'message' => __('Backup deleted successfully', 'wp-remote-manager')
            );
        } else {
            return array(
                'success' => false,
                'message' => __('Failed to delete backup file', 'wp-remote-manager')
            );
        }
    }
    
    /**
     * Clean old backups (keep only last N backups)
     */
    public function cleanup_old_backups($keep_count = 5) {
        $backups = $this->get_backups();
        
        if (count($backups) <= $keep_count) {
            return;
        }
        
        $to_delete = array_slice($backups, $keep_count);
        
        foreach ($to_delete as $backup) {
            unlink($backup['path']);
        }
    }
}