<?php
/**
 * Site health monitoring class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WRM_Site_Health {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('wrm_health_check', array($this, 'perform_health_check'));
    }
    
    /**
     * Get comprehensive site health data
     */
    public function get_site_health() {
        $health_data = array();
        
        // WordPress core health
        $health_data['wordpress'] = $this->check_wordpress_health();
        
        // PHP health
        $health_data['php'] = $this->check_php_health();
        
        // Database health
        $health_data['database'] = $this->check_database_health();
        
        // File system health
        $health_data['filesystem'] = $this->check_filesystem_health();
        
        // Security health
        $health_data['security'] = $this->check_security_health();
        
        // Performance health
        $health_data['performance'] = $this->check_performance_health();
        
        // Calculate overall score
        $health_data['overall_score'] = $this->calculate_overall_score($health_data);
        $health_data['last_check'] = current_time('mysql');
        
        return apply_filters('wrm_site_health_data', $health_data);
    }
    
    /**
     * Perform scheduled health check
     */
    public function perform_health_check() {
        if (!get_option('wrm_site_health_enabled', true)) {
            return;
        }
        
        $health_data = $this->get_site_health();
        $database = new WRM_Database();
        
        // Store individual metrics
        foreach ($health_data as $category => $data) {
            if ($category === 'overall_score' || $category === 'last_check') {
                continue;
            }
            
            $database->store_health_data(
                $category,
                maybe_serialize($data),
                $data['score'] ?? 0,
                $data['status'] ?? 'unknown'
            );
        }
        
        // Store overall score
        $database->store_health_data(
            'overall_score',
            $health_data['overall_score'],
            $health_data['overall_score'],
            $this->get_score_status($health_data['overall_score'])
        );
        
        WP_Remote_Manager::log_activity('health_check_completed', "Overall health score: {$health_data['overall_score']}");
    }
    
    /**
     * Check WordPress health
     */
    private function check_wordpress_health() {
        global $wp_version;
        
        $health = array(
            'version' => $wp_version,
            'latest_version' => $this->get_latest_wp_version(),
            'updates_available' => false,
            'auto_updates_enabled' => wp_is_auto_update_enabled_for_type('core'),
            'score' => 100,
            'status' => 'good',
            'issues' => array()
        );
        
        // Check for updates
        $updates = get_core_updates();
        if (!empty($updates) && $updates[0]->response !== 'latest') {
            $health['updates_available'] = true;
            $health['latest_version'] = $updates[0]->version;
            $health['score'] -= 20;
            $health['status'] = 'warning';
            $health['issues'][] = __('WordPress update available', 'wp-remote-manager');
        }
        
        // Check WordPress constants
        if (!defined('WP_DEBUG') || WP_DEBUG) {
            $health['score'] -= 5;
            $health['issues'][] = __('Debug mode is enabled', 'wp-remote-manager');
        }
        
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            $health['debug_log_enabled'] = true;
        }
        
        return $health;
    }
    
    /**
     * Check PHP health
     */
    private function check_php_health() {
        $health = array(
            'version' => PHP_VERSION,
            'recommended_version' => '8.0',
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size'),
            'score' => 100,
            'status' => 'good',
            'issues' => array()
        );
        
        // Check PHP version
        if (version_compare(PHP_VERSION, '7.4', '<')) {
            $health['score'] -= 30;
            $health['status'] = 'critical';
            $health['issues'][] = __('PHP version is outdated and unsupported', 'wp-remote-manager');
        } elseif (version_compare(PHP_VERSION, '8.0', '<')) {
            $health['score'] -= 10;
            $health['status'] = 'warning';
            $health['issues'][] = __('PHP version should be updated', 'wp-remote-manager');
        }
        
        // Check memory limit
        $memory_limit = wp_convert_hr_to_bytes(ini_get('memory_limit'));
        if ($memory_limit < 128 * 1024 * 1024) { // Less than 128MB
            $health['score'] -= 15;
            $health['status'] = 'warning';
            $health['issues'][] = __('PHP memory limit is low', 'wp-remote-manager');
        }
        
        // Check required extensions
        $required_extensions = array('curl', 'gd', 'mbstring', 'mysql', 'zip');
        foreach ($required_extensions as $extension) {
            if (!extension_loaded($extension)) {
                $health['score'] -= 10;
                $health['status'] = 'warning';
                $health['issues'][] = sprintf(__('PHP extension %s is not loaded', 'wp-remote-manager'), $extension);
            }
        }
        
        return $health;
    }
    
    /**
     * Check database health
     */
    private function check_database_health() {
        global $wpdb;
        
        $health = array(
            'version' => $wpdb->get_var("SELECT VERSION()"),
            'charset' => $wpdb->charset,
            'collate' => $wpdb->collate,
            'score' => 100,
            'status' => 'good',
            'issues' => array()
        );
        
        // Check database connection
        if (!$wpdb->check_connection()) {
            $health['score'] = 0;
            $health['status'] = 'critical';
            $health['issues'][] = __('Database connection failed', 'wp-remote-manager');
            return $health;
        }
        
        // Check MySQL version
        $mysql_version = $health['version'];
        if (version_compare($mysql_version, '5.6', '<')) {
            $health['score'] -= 20;
            $health['status'] = 'warning';
            $health['issues'][] = __('MySQL version is outdated', 'wp-remote-manager');
        }
        
        // Check table health
        $tables = $wpdb->get_results("SHOW TABLE STATUS", ARRAY_A);
        foreach ($tables as $table) {
            if ($table['Engine'] !== 'InnoDB' && strpos($table['Name'], $wpdb->prefix) === 0) {
                $health['score'] -= 5;
                $health['issues'][] = sprintf(__('Table %s is not using InnoDB engine', 'wp-remote-manager'), $table['Name']);
            }
        }
        
        return $health;
    }
    
    /**
     * Check filesystem health
     */
    private function check_filesystem_health() {
        $health = array(
            'wp_content_writable' => wp_is_writable(WP_CONTENT_DIR),
            'uploads_writable' => wp_is_writable(wp_upload_dir()['basedir']),
            'score' => 100,
            'status' => 'good',
            'issues' => array()
        );
        
        // Check critical directories
        if (!$health['wp_content_writable']) {
            $health['score'] -= 30;
            $health['status'] = 'critical';
            $health['issues'][] = __('wp-content directory is not writable', 'wp-remote-manager');
        }
        
        if (!$health['uploads_writable']) {
            $health['score'] -= 20;
            $health['status'] = 'warning';
            $health['issues'][] = __('Uploads directory is not writable', 'wp-remote-manager');
        }
        
        // Check disk space
        $upload_dir = wp_upload_dir();
        if (function_exists('disk_free_space')) {
            $free_space = disk_free_space($upload_dir['basedir']);
            $total_space = disk_total_space($upload_dir['basedir']);
            
            if ($free_space !== false && $total_space !== false) {
                $usage_percentage = (($total_space - $free_space) / $total_space) * 100;
                $health['disk_usage_percentage'] = round($usage_percentage, 2);
                
                if ($usage_percentage > 90) {
                    $health['score'] -= 25;
                    $health['status'] = 'critical';
                    $health['issues'][] = __('Disk space is critically low', 'wp-remote-manager');
                } elseif ($usage_percentage > 80) {
                    $health['score'] -= 10;
                    $health['status'] = 'warning';
                    $health['issues'][] = __('Disk space is running low', 'wp-remote-manager');
                }
            }
        }
        
        return $health;
    }
    
    /**
     * Check security health
     */
    private function check_security_health() {
        $health = array(
            'ssl_enabled' => is_ssl(),
            'admin_user_exists' => username_exists('admin'),
            'file_editing_disabled' => defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT,
            'score' => 100,
            'status' => 'good',
            'issues' => array()
        );
        
        // Check SSL
        if (!$health['ssl_enabled']) {
            $health['score'] -= 20;
            $health['status'] = 'warning';
            $health['issues'][] = __('SSL is not enabled', 'wp-remote-manager');
        }
        
        // Check admin username
        if ($health['admin_user_exists']) {
            $health['score'] -= 15;
            $health['status'] = 'warning';
            $health['issues'][] = __('Default admin username exists', 'wp-remote-manager');
        }
        
        // Check file editing
        if (!$health['file_editing_disabled']) {
            $health['score'] -= 10;
            $health['issues'][] = __('File editing is not disabled', 'wp-remote-manager');
        }
        
        // Check WordPress version in meta tags
        if (get_option('blog_public')) {
            $health['search_engine_visibility'] = false;
            $health['score'] -= 5;
            $health['issues'][] = __('Site is visible to search engines in development', 'wp-remote-manager');
        }
        
        return $health;
    }
    
    /**
     * Check performance health
     */
    private function check_performance_health() {
        $health = array(
            'object_cache_enabled' => wp_using_ext_object_cache(),
            'opcache_enabled' => function_exists('opcache_get_status') && opcache_get_status() !== false,
            'gzip_enabled' => $this->is_gzip_enabled(),
            'score' => 100,
            'status' => 'good',
            'issues' => array()
        );
        
        // Check object cache
        if (!$health['object_cache_enabled']) {
            $health['score'] -= 15;
            $health['status'] = 'warning';
            $health['issues'][] = __('Object cache is not enabled', 'wp-remote-manager');
        }
        
        // Check OPCache
        if (!$health['opcache_enabled']) {
            $health['score'] -= 10;
            $health['issues'][] = __('OPCache is not enabled', 'wp-remote-manager');
        }
        
        // Check GZIP
        if (!$health['gzip_enabled']) {
            $health['score'] -= 10;
            $health['issues'][] = __('GZIP compression is not enabled', 'wp-remote-manager');
        }
        
        // Check active plugins count
        $active_plugins = get_option('active_plugins', array());
        $plugin_count = count($active_plugins);
        if ($plugin_count > 30) {
            $health['score'] -= 5;
            $health['issues'][] = __('Large number of active plugins may affect performance', 'wp-remote-manager');
        }
        
        $health['active_plugins_count'] = $plugin_count;
        
        return $health;
    }
    
    /**
     * Calculate overall health score
     */
    private function calculate_overall_score($health_data) {
        $total_score = 0;
        $categories = 0;
        
        foreach ($health_data as $category => $data) {
            if (isset($data['score'])) {
                $total_score += $data['score'];
                $categories++;
            }
        }
        
        return $categories > 0 ? round($total_score / $categories) : 0;
    }
    
    /**
     * Get status based on score
     */
    private function get_score_status($score) {
        if ($score >= 80) {
            return 'good';
        } elseif ($score >= 60) {
            return 'warning';
        } else {
            return 'critical';
        }
    }
    
    /**
     * Get latest WordPress version
     */
    private function get_latest_wp_version() {
        $version_check = get_transient('wrm_latest_wp_version');
        if ($version_check === false) {
            $response = wp_remote_get('https://api.wordpress.org/core/version-check/1.7/');
            if (!is_wp_error($response)) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);
                if (isset($data['offers'][0]['version'])) {
                    $version_check = $data['offers'][0]['version'];
                    set_transient('wrm_latest_wp_version', $version_check, HOUR_IN_SECONDS);
                }
            }
        }
        
        return $version_check ?: get_bloginfo('version');
    }
    
    /**
     * Check if GZIP is enabled
     */
    private function is_gzip_enabled() {
        if (function_exists('gzencode')) {
            $test_string = 'test compression';
            $compressed = gzencode($test_string);
            return $compressed !== false && strlen($compressed) < strlen($test_string);
        }
        
        return false;
    }
}