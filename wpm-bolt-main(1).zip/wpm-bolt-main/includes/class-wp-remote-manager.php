<?php
/**
 * Main plugin class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WP_Remote_Manager {
    
    /**
     * Single instance of the class
     */
    private static $instance = null;
    
    /**
     * Plugin components
     */
    public $database;
    public $admin;
    public $api;
    public $security;
    public $site_health;
    public $backup;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init_hooks();
        $this->init_components();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        add_action('init', array($this, 'load_textdomain'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
    }
    
    /**
     * Initialize plugin components
     */
    private function init_components() {
        $this->database = new WRM_Database();
        $this->security = new WRM_Security();
        $this->site_health = new WRM_Site_Health();
        $this->backup = new WRM_Backup();
        $this->api = new WRM_API();
        
        if (is_admin()) {
            $this->admin = new WRM_Admin();
        }
    }
    
    /**
     * Load plugin text domain
     */
    public function load_textdomain() {
        load_plugin_textdomain('wp-remote-manager', false, dirname(WRM_PLUGIN_BASENAME) . '/languages');
    }
    
    /**
     * Enqueue frontend scripts
     */
    public function enqueue_frontend_scripts() {
        // Only enqueue if maintenance mode is active
        if (get_option('wrm_maintenance_mode', false)) {
            wp_enqueue_style('wrm-maintenance', WRM_PLUGIN_URL . 'assets/css/maintenance.css', array(), WRM_VERSION);
        }
    }
    
    /**
     * Plugin activation
     */
    public static function activate() {
        // Create database tables
        $database = new WRM_Database();
        $database->create_tables();
        
        // Set default options
        add_option('wrm_api_key', wp_generate_password(32, false));
        add_option('wrm_allowed_ips', array());
        add_option('wrm_maintenance_mode', false);
        add_option('wrm_log_retention_days', 30);
        add_option('wrm_site_health_enabled', true);
        
        // Schedule health check
        if (!wp_next_scheduled('wrm_health_check')) {
            wp_schedule_event(time(), 'hourly', 'wrm_health_check');
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public static function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('wrm_health_check');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin uninstall
     */
    public static function uninstall() {
        global $wpdb;
        
        // Remove database tables
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}wrm_logs");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}wrm_site_health");
        
        // Remove options
        delete_option('wrm_api_key');
        delete_option('wrm_allowed_ips');
        delete_option('wrm_maintenance_mode');
        delete_option('wrm_log_retention_days');
        delete_option('wrm_site_health_enabled');
        
        // Clear scheduled events
        wp_clear_scheduled_hook('wrm_health_check');
    }
    
    /**
     * Log activity
     */
    public static function log_activity($action, $details = '', $status = 'success') {
        $database = new WRM_Database();
        $database->log_activity($action, $details, $status);
        
        do_action('wrm_log_activity', $action, $details, $status);
    }
    
    /**
     * Get plugin version
     */
    public function get_version() {
        return WRM_VERSION;
    }
}