<?php
/**
 * Admin interface class
 */

if (!defined('ABSPATH')) {
    exit;
}

class WRM_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('admin_init', array($this, 'handle_admin_actions'));
        add_action('wp_ajax_wrm_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_wrm_generate_api_key', array($this, 'ajax_generate_api_key'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Remote Manager', 'wp-remote-manager'),
            __('Remote Manager', 'wp-remote-manager'),
            'manage_options',
            'wp-remote-manager',
            array($this, 'dashboard_page'),
            'dashicons-admin-tools',
            30
        );
        
        add_submenu_page(
            'wp-remote-manager',
            __('Dashboard', 'wp-remote-manager'),
            __('Dashboard', 'wp-remote-manager'),
            'manage_options',
            'wp-remote-manager',
            array($this, 'dashboard_page')
        );
        
        add_submenu_page(
            'wp-remote-manager',
            __('Settings', 'wp-remote-manager'),
            __('Settings', 'wp-remote-manager'),
            'manage_options',
            'wrm-settings',
            array($this, 'settings_page')
        );
        
        add_submenu_page(
            'wp-remote-manager',
            __('Activity Logs', 'wp-remote-manager'),
            __('Activity Logs', 'wp-remote-manager'),
            'manage_options',
            'wrm-logs',
            array($this, 'logs_page')
        );
        
        add_submenu_page(
            'wp-remote-manager',
            __('Site Health', 'wp-remote-manager'),
            __('Site Health', 'wp-remote-manager'),
            'manage_options',
            'wrm-health',
            array($this, 'health_page')
        );
        
        add_submenu_page(
            'wp-remote-manager',
            __('API Documentation', 'wp-remote-manager'),
            __('API Docs', 'wp-remote-manager'),
            'manage_options',
            'wrm-api-docs',
            array($this, 'api_docs_page')
        );
    }
    
    /**
     * Enqueue admin scripts and styles
     */
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'wp-remote-manager') === false && strpos($hook, 'wrm-') === false) {
            return;
        }
        
        wp_enqueue_style('wrm-admin', WRM_PLUGIN_URL . 'assets/css/admin.css', array(), WRM_VERSION);
        wp_enqueue_script('wrm-admin', WRM_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), WRM_VERSION, true);
        
        wp_localize_script('wrm-admin', 'wrm_ajax', array(
            'url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('wrm_admin_nonce'),
            'strings' => array(
                'confirm_generate' => __('Are you sure you want to generate a new API key? This will invalidate the current key.', 'wp-remote-manager'),
                'testing_connection' => __('Testing connection...', 'wp-remote-manager'),
                'connection_success' => __('Connection successful!', 'wp-remote-manager'),
                'connection_failed' => __('Connection failed!', 'wp-remote-manager')
            )
        ));
    }
    
    /**
     * Handle admin actions
     */
    public function handle_admin_actions() {
        if (!isset($_POST['wrm_action']) || !wp_verify_nonce($_POST['wrm_nonce'] ?? '', 'wrm_admin_action')) {
            return;
        }
        
        switch ($_POST['wrm_action']) {
            case 'save_settings':
                $this->save_settings();
                break;
            case 'toggle_maintenance':
                $this->toggle_maintenance_mode();
                break;
            case 'clear_logs':
                $this->clear_logs();
                break;
        }
    }
    
    /**
     * Dashboard page
     */
    public function dashboard_page() {
        $site_health = new WRM_Site_Health();
        $health_data = $site_health->get_site_health();
        $database = new WRM_Database();
        $recent_logs = $database->get_logs(10);
        
        include WRM_PLUGIN_DIR . 'templates/admin-dashboard.php';
    }
    
    /**
     * Settings page
     */
    public function settings_page() {
        include WRM_PLUGIN_DIR . 'templates/admin-settings.php';
    }
    
    /**
     * Logs page
     */
    public function logs_page() {
        $database = new WRM_Database();
        $page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $per_page = 20;
        $offset = ($page - 1) * $per_page;
        
        $filters = array();
        if (!empty($_GET['action_filter'])) {
            $filters['action'] = sanitize_text_field($_GET['action_filter']);
        }
        if (!empty($_GET['status_filter'])) {
            $filters['status'] = sanitize_text_field($_GET['status_filter']);
        }
        
        $logs = $database->get_logs($per_page, $offset, $filters);
        
        include WRM_PLUGIN_DIR . 'templates/admin-logs.php';
    }
    
    /**
     * Site health page
     */
    public function health_page() {
        $site_health = new WRM_Site_Health();
        $health_data = $site_health->get_site_health();
        
        include WRM_PLUGIN_DIR . 'templates/admin-health.php';
    }
    
    /**
     * API documentation page
     */
    public function api_docs_page() {
        include WRM_PLUGIN_DIR . 'templates/admin-api-docs.php';
    }
    
    /**
     * Save settings
     */
    private function save_settings() {
        $allowed_ips = array();
        if (!empty($_POST['wrm_allowed_ips'])) {
            $ips = explode("\n", sanitize_textarea_field($_POST['wrm_allowed_ips']));
            foreach ($ips as $ip) {
                $ip = trim($ip);
                if (!empty($ip)) {
                    $allowed_ips[] = $ip;
                }
            }
        }
        
        update_option('wrm_allowed_ips', $allowed_ips);
        update_option('wrm_log_retention_days', intval($_POST['wrm_log_retention_days'] ?? 30));
        update_option('wrm_site_health_enabled', !empty($_POST['wrm_site_health_enabled']));
        
        WP_Remote_Manager::log_activity('settings_updated', 'Plugin settings were updated');
        
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success"><p>' . __('Settings saved successfully!', 'wp-remote-manager') . '</p></div>';
        });
    }
    
    /**
     * Toggle maintenance mode
     */
    private function toggle_maintenance_mode() {
        $current_mode = get_option('wrm_maintenance_mode', false);
        $new_mode = !$current_mode;
        
        update_option('wrm_maintenance_mode', $new_mode);
        
        $status = $new_mode ? 'enabled' : 'disabled';
        WP_Remote_Manager::log_activity('maintenance_mode_toggled', "Maintenance mode {$status}");
        
        $message = $new_mode ? 
            __('Maintenance mode enabled!', 'wp-remote-manager') : 
            __('Maintenance mode disabled!', 'wp-remote-manager');
        
        add_action('admin_notices', function() use ($message) {
            echo '<div class="notice notice-success"><p>' . $message . '</p></div>';
        });
    }
    
    /**
     * Clear logs
     */
    private function clear_logs() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'wrm_logs';
        $wpdb->query("TRUNCATE TABLE $table");
        
        WP_Remote_Manager::log_activity('logs_cleared', 'All activity logs were cleared');
        
        add_action('admin_notices', function() {
            echo '<div class="notice notice-success"><p>' . __('Activity logs cleared!', 'wp-remote-manager') . '</p></div>';
        });
    }
    
    /**
     * AJAX: Test connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('wrm_admin_nonce', 'nonce');
        
        $api_key = get_option('wrm_api_key');
        $test_url = home_url('/wp-json/wrm/v1/status');
        
        $response = wp_remote_get($test_url, array(
            'headers' => array(
                'X-WRM-API-Key' => $api_key
            ),
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => $response->get_error_message()));
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code === 200) {
            wp_send_json_success(array('message' => __('Connection successful!', 'wp-remote-manager')));
        } else {
            wp_send_json_error(array('message' => __('Connection failed with status: ', 'wp-remote-manager') . $status_code));
        }
    }
    
    /**
     * AJAX: Generate new API key
     */
    public function ajax_generate_api_key() {
        check_ajax_referer('wrm_admin_nonce', 'nonce');
        
        $new_key = wp_generate_password(32, false);
        update_option('wrm_api_key', $new_key);
        
        WP_Remote_Manager::log_activity('api_key_generated', 'New API key generated');
        
        wp_send_json_success(array(
            'api_key' => $new_key,
            'message' => __('New API key generated successfully!', 'wp-remote-manager')
        ));
    }
}