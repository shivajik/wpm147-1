<?php
if (!defined('ABSPATH')) {
    exit;
}

$api_key = get_option('wrm_api_key');
$maintenance_mode = get_option('wrm_maintenance_mode', false);
?>

<div class="wrap wrm-admin">
    <h1><?php _e('WP Remote Manager Dashboard', 'wp-remote-manager'); ?></h1>
    
    <div class="wrm-dashboard-grid">
        <!-- Site Health Overview -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><?php _e('Site Health Overview', 'wp-remote-manager'); ?></h2>
                <div class="wrm-health-score">
                    <div class="wrm-score-circle" data-score="<?php echo esc_attr($health_data['overall_score']); ?>">
                        <span class="wrm-score-text"><?php echo esc_html($health_data['overall_score']); ?>%</span>
                    </div>
                </div>
            </div>
            <div class="wrm-card-body">
                <div class="wrm-health-categories">
                    <?php foreach ($health_data as $category => $data): ?>
                        <?php if ($category === 'overall_score' || $category === 'last_check') continue; ?>
                        <div class="wrm-health-item">
                            <span class="wrm-health-label"><?php echo esc_html(ucfirst($category)); ?></span>
                            <span class="wrm-health-status wrm-status-<?php echo esc_attr($data['status']); ?>">
                                <?php echo esc_html($data['score']); ?>%
                            </span>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="wrm-last-check">
                    <?php printf(__('Last check: %s', 'wp-remote-manager'), esc_html($health_data['last_check'])); ?>
                </p>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><?php _e('Quick Actions', 'wp-remote-manager'); ?></h2>
            </div>
            <div class="wrm-card-body">
                <form method="post" action="">
                    <?php wp_nonce_field('wrm_admin_action', 'wrm_nonce'); ?>
                    <input type="hidden" name="wrm_action" value="toggle_maintenance">
                    <button type="submit" class="button button-<?php echo $maintenance_mode ? 'secondary' : 'primary'; ?>">
                        <?php echo $maintenance_mode ? __('Disable Maintenance Mode', 'wp-remote-manager') : __('Enable Maintenance Mode', 'wp-remote-manager'); ?>
                    </button>
                </form>
                
                <button type="button" class="button" id="wrm-test-connection">
                    <?php _e('Test API Connection', 'wp-remote-manager'); ?>
                </button>
                
                <a href="<?php echo admin_url('admin.php?page=wrm-health'); ?>" class="button">
                    <?php _e('Run Health Check', 'wp-remote-manager'); ?>
                </a>
            </div>
        </div>
        
        <!-- Site Information -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><?php _e('Site Information', 'wp-remote-manager'); ?></h2>
            </div>
            <div class="wrm-card-body">
                <div class="wrm-info-grid">
                    <div class="wrm-info-item">
                        <strong><?php _e('WordPress Version:', 'wp-remote-manager'); ?></strong>
                        <?php echo esc_html(get_bloginfo('version')); ?>
                    </div>
                    <div class="wrm-info-item">
                        <strong><?php _e('PHP Version:', 'wp-remote-manager'); ?></strong>
                        <?php echo esc_html(PHP_VERSION); ?>
                    </div>
                    <div class="wrm-info-item">
                        <strong><?php _e('Active Theme:', 'wp-remote-manager'); ?></strong>
                        <?php echo esc_html(wp_get_theme()->get('Name')); ?>
                    </div>
                    <div class="wrm-info-item">
                        <strong><?php _e('Active Plugins:', 'wp-remote-manager'); ?></strong>
                        <?php echo count(get_option('active_plugins', array())); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- API Configuration -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><?php _e('API Configuration', 'wp-remote-manager'); ?></h2>
            </div>
            <div class="wrm-card-body">
                <div class="wrm-api-info">
                    <p><strong><?php _e('API Endpoint:', 'wp-remote-manager'); ?></strong></p>
                    <code><?php echo esc_html(home_url('/wp-json/wrm/v1/')); ?></code>
                    
                    <p><strong><?php _e('API Key:', 'wp-remote-manager'); ?></strong></p>
                    <div class="wrm-api-key-field">
                        <input type="text" value="<?php echo esc_attr($api_key); ?>" readonly class="regular-text">
                        <button type="button" class="button" id="wrm-generate-key">
                            <?php _e('Generate New Key', 'wp-remote-manager'); ?>
                        </button>
                    </div>
                </div>
                
                <p class="description">
                    <?php _e('Use this API key in the X-WRM-API-Key header for all API requests.', 'wp-remote-manager'); ?>
                </p>
            </div>
        </div>
        
        <!-- Recent Activity -->
        <div class="wrm-card wrm-card-wide">
            <div class="wrm-card-header">
                <h2><?php _e('Recent Activity', 'wp-remote-manager'); ?></h2>
                <a href="<?php echo admin_url('admin.php?page=wrm-logs'); ?>" class="button button-small">
                    <?php _e('View All Logs', 'wp-remote-manager'); ?>
                </a>
            </div>
            <div class="wrm-card-body">
                <?php if (!empty($recent_logs)): ?>
                    <div class="wrm-logs-table">
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Action', 'wp-remote-manager'); ?></th>
                                    <th><?php _e('Details', 'wp-remote-manager'); ?></th>
                                    <th><?php _e('Status', 'wp-remote-manager'); ?></th>
                                    <th><?php _e('Date', 'wp-remote-manager'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_logs as $log): ?>
                                    <tr>
                                        <td><?php echo esc_html($log->action); ?></td>
                                        <td><?php echo esc_html(wp_trim_words($log->details, 10)); ?></td>
                                        <td>
                                            <span class="wrm-status-badge wrm-status-<?php echo esc_attr($log->status); ?>">
                                                <?php echo esc_html(ucfirst($log->status)); ?>
                                            </span>
                                        </td>
                                        <td><?php echo esc_html(mysql2date('Y-m-d H:i:s', $log->created_at)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p><?php _e('No recent activity found.', 'wp-remote-manager'); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>