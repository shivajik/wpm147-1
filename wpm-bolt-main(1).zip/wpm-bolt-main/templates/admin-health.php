<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wrm-admin">
    <h1><?php _e('Site Health', 'wp-remote-manager'); ?></h1>
    
    <!-- Overall Health Score -->
    <div class="wrm-card">
        <div class="wrm-card-header">
            <h2><?php _e('Overall Health Score', 'wp-remote-manager'); ?></h2>
            <div class="wrm-health-score">
                <div class="wrm-score-circle" data-score="<?php echo esc_attr($health_data['overall_score']); ?>">
                    <span class="wrm-score-text"><?php echo esc_html($health_data['overall_score']); ?>%</span>
                </div>
            </div>
        </div>
        <div class="wrm-card-body">
            <p class="wrm-last-check">
                <?php printf(__('Last updated: %s', 'wp-remote-manager'), esc_html($health_data['last_check'])); ?>
            </p>
        </div>
    </div>
    
    <!-- Health Categories -->
    <div class="wrm-dashboard-grid">
        <?php foreach ($health_data as $category => $data): ?>
            <?php if ($category === 'overall_score' || $category === 'last_check') continue; ?>
            
            <div class="wrm-card">
                <div class="wrm-card-header">
                    <h2><?php echo esc_html(ucfirst($category)); ?> <?php _e('Health', 'wp-remote-manager'); ?></h2>
                    <span class="wrm-health-status wrm-status-<?php echo esc_attr($data['status']); ?>">
                        <?php echo esc_html($data['score']); ?>%
                    </span>
                </div>
                <div class="wrm-card-body">
                    <?php if (!empty($data['issues'])): ?>
                        <div class="wrm-health-issues">
                            <h4><?php _e('Issues Found:', 'wp-remote-manager'); ?></h4>
                            <ul>
                                <?php foreach ($data['issues'] as $issue): ?>
                                    <li><?php echo esc_html($issue); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($category === 'wordpress'): ?>
                        <div class="wrm-health-details">
                            <p><strong><?php _e('Current Version:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['version']); ?></p>
                            <?php if (isset($data['latest_version'])): ?>
                                <p><strong><?php _e('Latest Version:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['latest_version']); ?></p>
                            <?php endif; ?>
                            <p><strong><?php _e('Auto Updates:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['auto_updates_enabled'] ? __('Enabled', 'wp-remote-manager') : __('Disabled', 'wp-remote-manager'); ?>
                            </p>
                        </div>
                    <?php elseif ($category === 'php'): ?>
                        <div class="wrm-health-details">
                            <p><strong><?php _e('PHP Version:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['version']); ?></p>
                            <p><strong><?php _e('Memory Limit:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['memory_limit']); ?></p>
                            <p><strong><?php _e('Max Execution Time:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['max_execution_time']); ?>s</p>
                            <p><strong><?php _e('Upload Max Filesize:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['upload_max_filesize']); ?></p>
                        </div>
                    <?php elseif ($category === 'database'): ?>
                        <div class="wrm-health-details">
                            <p><strong><?php _e('Database Version:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['version']); ?></p>
                            <p><strong><?php _e('Charset:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['charset']); ?></p>
                            <p><strong><?php _e('Collation:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['collate']); ?></p>
                        </div>
                    <?php elseif ($category === 'filesystem'): ?>
                        <div class="wrm-health-details">
                            <p><strong><?php _e('wp-content Writable:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['wp_content_writable'] ? __('Yes', 'wp-remote-manager') : __('No', 'wp-remote-manager'); ?>
                            </p>
                            <p><strong><?php _e('Uploads Writable:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['uploads_writable'] ? __('Yes', 'wp-remote-manager') : __('No', 'wp-remote-manager'); ?>
                            </p>
                            <?php if (isset($data['disk_usage_percentage'])): ?>
                                <p><strong><?php _e('Disk Usage:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['disk_usage_percentage']); ?>%</p>
                            <?php endif; ?>
                        </div>
                    <?php elseif ($category === 'security'): ?>
                        <div class="wrm-health-details">
                            <p><strong><?php _e('SSL Enabled:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['ssl_enabled'] ? __('Yes', 'wp-remote-manager') : __('No', 'wp-remote-manager'); ?>
                            </p>
                            <p><strong><?php _e('File Editing Disabled:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['file_editing_disabled'] ? __('Yes', 'wp-remote-manager') : __('No', 'wp-remote-manager'); ?>
                            </p>
                            <p><strong><?php _e('Admin User Exists:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['admin_user_exists'] ? __('Yes', 'wp-remote-manager') : __('No', 'wp-remote-manager'); ?>
                            </p>
                        </div>
                    <?php elseif ($category === 'performance'): ?>
                        <div class="wrm-health-details">
                            <p><strong><?php _e('Object Cache:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['object_cache_enabled'] ? __('Enabled', 'wp-remote-manager') : __('Disabled', 'wp-remote-manager'); ?>
                            </p>
                            <p><strong><?php _e('OPCache:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['opcache_enabled'] ? __('Enabled', 'wp-remote-manager') : __('Disabled', 'wp-remote-manager'); ?>
                            </p>
                            <p><strong><?php _e('GZIP Compression:', 'wp-remote-manager'); ?></strong> 
                                <?php echo $data['gzip_enabled'] ? __('Enabled', 'wp-remote-manager') : __('Disabled', 'wp-remote-manager'); ?>
                            </p>
                            <?php if (isset($data['active_plugins_count'])): ?>
                                <p><strong><?php _e('Active Plugins:', 'wp-remote-manager'); ?></strong> <?php echo esc_html($data['active_plugins_count']); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<style>
.wrm-health-issues {
    background: #fff2cd;
    border: 1px solid #ffd60a;
    border-radius: 4px;
    padding: 15px;
    margin-bottom: 15px;
}

.wrm-health-issues h4 {
    margin: 0 0 10px 0;
    color: #856404;
}

.wrm-health-issues ul {
    margin: 0;
    padding-left: 20px;
}

.wrm-health-issues li {
    color: #856404;
    margin-bottom: 5px;
}

.wrm-health-details p {
    margin: 5px 0;
    padding: 5px 0;
    border-bottom: 1px solid #f0f0f1;
}

.wrm-health-details p:last-child {
    border-bottom: none;
}
</style>