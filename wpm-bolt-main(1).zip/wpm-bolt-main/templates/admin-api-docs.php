<?php
if (!defined('ABSPATH')) {
    exit;
}

$api_base = home_url('/wp-json/wrm/v1');
$api_key = get_option('wrm_api_key');
?>

<div class="wrap wrm-admin">
    <h1><?php _e('API Documentation', 'wp-remote-manager'); ?></h1>
    
    <!-- API Overview -->
    <div class="wrm-card">
        <div class="wrm-card-header">
            <h2><?php _e('API Overview', 'wp-remote-manager'); ?></h2>
        </div>
        <div class="wrm-card-body">
            <p><?php _e('The WP Remote Manager API allows you to remotely manage and monitor your WordPress site. All API requests require authentication using your API key.', 'wp-remote-manager'); ?></p>
            
            <h3><?php _e('Base URL', 'wp-remote-manager'); ?></h3>
            <code><?php echo esc_html($api_base); ?></code>
            
            <h3><?php _e('Authentication', 'wp-remote-manager'); ?></h3>
            <p><?php _e('Include your API key in the request headers:', 'wp-remote-manager'); ?></p>
            <pre><code>X-WRM-API-Key: <?php echo esc_html($api_key); ?></code></pre>
            
            <h3><?php _e('Response Format', 'wp-remote-manager'); ?></h3>
            <p><?php _e('All responses are returned in JSON format.', 'wp-remote-manager'); ?></p>
        </div>
    </div>
    
    <!-- Endpoints -->
    <div class="wrm-api-endpoints">
        
        <!-- Status Endpoint -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><span class="wrm-method-badge wrm-method-get">GET</span> /status</h2>
            </div>
            <div class="wrm-card-body">
                <p><?php _e('Get comprehensive site status and information.', 'wp-remote-manager'); ?></p>
                
                <h4><?php _e('Example Request:', 'wp-remote-manager'); ?></h4>
                <pre><code>curl -X GET "<?php echo esc_html($api_base); ?>/status" \
  -H "X-WRM-API-Key: <?php echo esc_html($api_key); ?>"</code></pre>
                
                <h4><?php _e('Example Response:', 'wp-remote-manager'); ?></h4>
                <pre><code>{
  "site_url": "<?php echo esc_html(home_url()); ?>",
  "wordpress_version": "<?php echo esc_html(get_bloginfo('version')); ?>",
  "php_version": "<?php echo esc_html(PHP_VERSION); ?>",
  "theme": {
    "name": "<?php echo esc_html(wp_get_theme()->get('Name')); ?>",
    "version": "<?php echo esc_html(wp_get_theme()->get('Version')); ?>"
  },
  "maintenance_mode": <?php echo get_option('wrm_maintenance_mode', false) ? 'true' : 'false'; ?>,
  "ssl_enabled": <?php echo is_ssl() ? 'true' : 'false'; ?>,
  "timestamp": "<?php echo esc_html(current_time('c')); ?>"
}</code></pre>
            </div>
        </div>
        
        <!-- Updates Endpoint -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><span class="wrm-method-badge wrm-method-get">GET</span> /updates</h2>
            </div>
            <div class="wrm-card-body">
                <p><?php _e('Get available updates for WordPress core, plugins, and themes.', 'wp-remote-manager'); ?></p>
                
                <h4><?php _e('Example Request:', 'wp-remote-manager'); ?></h4>
                <pre><code>curl -X GET "<?php echo esc_html($api_base); ?>/updates" \
  -H "X-WRM-API-Key: <?php echo esc_html($api_key); ?>"</code></pre>
                
                <h4><?php _e('Example Response:', 'wp-remote-manager'); ?></h4>
                <pre><code>{
  "wordpress": {
    "current_version": "6.4.0",
    "new_version": "6.4.1",
    "update_available": true
  },
  "plugins": [
    {
      "plugin": "example-plugin/example-plugin.php",
      "name": "Example Plugin",
      "current_version": "1.0.0",
      "new_version": "1.0.1"
    }
  ],
  "themes": []
}</code></pre>
            </div>
        </div>
        
        <!-- Perform Updates Endpoint -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><span class="wrm-method-badge wrm-method-post">POST</span> /updates/{type}</h2>
            </div>
            <div class="wrm-card-body">
                <p><?php _e('Perform updates for WordPress core, plugins, or themes.', 'wp-remote-manager'); ?></p>
                
                <h4><?php _e('Parameters:', 'wp-remote-manager'); ?></h4>
                <ul>
                    <li><code>type</code> - <?php _e('Update type: wordpress, plugins, or themes', 'wp-remote-manager'); ?></li>
                    <li><code>items</code> - <?php _e('(Optional) Array of specific items to update', 'wp-remote-manager'); ?></li>
                </ul>
                
                <h4><?php _e('Example Request:', 'wp-remote-manager'); ?></h4>
                <pre><code>curl -X POST "<?php echo esc_html($api_base); ?>/updates/plugins" \
  -H "X-WRM-API-Key: <?php echo esc_html($api_key); ?>" \
  -H "Content-Type: application/json" \
  -d '{"items": ["example-plugin/example-plugin.php"]}'</code></pre>
            </div>
        </div>
        
        <!-- Maintenance Mode Endpoint -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><span class="wrm-method-badge wrm-method-post">POST</span> /maintenance</h2>
            </div>
            <div class="wrm-card-body">
                <p><?php _e('Toggle maintenance mode on or off.', 'wp-remote-manager'); ?></p>
                
                <h4><?php _e('Parameters:', 'wp-remote-manager'); ?></h4>
                <ul>
                    <li><code>enable</code> - <?php _e('(Optional) Boolean to enable (true) or disable (false) maintenance mode. If not provided, toggles current state.', 'wp-remote-manager'); ?></li>
                </ul>
                
                <h4><?php _e('Example Request:', 'wp-remote-manager'); ?></h4>
                <pre><code>curl -X POST "<?php echo esc_html($api_base); ?>/maintenance" \
  -H "X-WRM-API-Key: <?php echo esc_html($api_key); ?>" \
  -H "Content-Type: application/json" \
  -d '{"enable": true}'</code></pre>
                
                <h4><?php _e('Example Response:', 'wp-remote-manager'); ?></h4>
                <pre><code>{
  "maintenance_mode": true,
  "message": "Maintenance mode enabled"
}</code></pre>
            </div>
        </div>
        
        <!-- Backup Endpoint -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><span class="wrm-method-badge wrm-method-post">POST</span> /backup</h2>
            </div>
            <div class="wrm-card-body">
                <p><?php _e('Create a backup of your site.', 'wp-remote-manager'); ?></p>
                
                <h4><?php _e('Parameters:', 'wp-remote-manager'); ?></h4>
                <ul>
                    <li><code>include_uploads</code> - <?php _e('(Optional) Boolean to include uploads directory in backup', 'wp-remote-manager'); ?></li>
                </ul>
                
                <h4><?php _e('Example Request:', 'wp-remote-manager'); ?></h4>
                <pre><code>curl -X POST "<?php echo esc_html($api_base); ?>/backup" \
  -H "X-WRM-API-Key: <?php echo esc_html($api_key); ?>" \
  -H "Content-Type: application/json" \
  -d '{"include_uploads": false}'</code></pre>
            </div>
        </div>
        
        <!-- Health Endpoint -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><span class="wrm-method-badge wrm-method-get">GET</span> /health</h2>
            </div>
            <div class="wrm-card-body">
                <p><?php _e('Get comprehensive site health information.', 'wp-remote-manager'); ?></p>
                
                <h4><?php _e('Example Request:', 'wp-remote-manager'); ?></h4>
                <pre><code>curl -X GET "<?php echo esc_html($api_base); ?>/health" \
  -H "X-WRM-API-Key: <?php echo esc_html($api_key); ?>"</code></pre>
            </div>
        </div>
        
        <!-- Logs Endpoint -->
        <div class="wrm-card">
            <div class="wrm-card-header">
                <h2><span class="wrm-method-badge wrm-method-get">GET</span> /logs</h2>
            </div>
            <div class="wrm-card-body">
                <p><?php _e('Get activity logs.', 'wp-remote-manager'); ?></p>
                
                <h4><?php _e('Parameters:', 'wp-remote-manager'); ?></h4>
                <ul>
                    <li><code>limit</code> - <?php _e('(Optional) Number of logs to return (default: 50)', 'wp-remote-manager'); ?></li>
                    <li><code>offset</code> - <?php _e('(Optional) Number of logs to skip (default: 0)', 'wp-remote-manager'); ?></li>
                </ul>
                
                <h4><?php _e('Example Request:', 'wp-remote-manager'); ?></h4>
                <pre><code>curl -X GET "<?php echo esc_html($api_base); ?>/logs?limit=10&offset=0" \
  -H "X-WRM-API-Key: <?php echo esc_html($api_key); ?>"</code></pre>
            </div>
        </div>
    </div>
    
    <!-- Error Codes -->
    <div class="wrm-card">
        <div class="wrm-card-header">
            <h2><?php _e('Error Codes', 'wp-remote-manager'); ?></h2>
        </div>
        <div class="wrm-card-body">
            <table class="wp-list-table widefat">
                <thead>
                    <tr>
                        <th><?php _e('Code', 'wp-remote-manager'); ?></th>
                        <th><?php _e('Description', 'wp-remote-manager'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>401</code></td>
                        <td><?php _e('Unauthorized - Invalid API key', 'wp-remote-manager'); ?></td>
                    </tr>
                    <tr>
                        <td><code>403</code></td>
                        <td><?php _e('Forbidden - IP address not allowed', 'wp-remote-manager'); ?></td>
                    </tr>
                    <tr>
                        <td><code>429</code></td>
                        <td><?php _e('Too Many Requests - Rate limit exceeded', 'wp-remote-manager'); ?></td>
                    </tr>
                    <tr>
                        <td><code>500</code></td>
                        <td><?php _e('Internal Server Error - Something went wrong', 'wp-remote-manager'); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.wrm-api-endpoints {
    display: grid;
    gap: 20px;
    margin-top: 20px;
}

.wrm-method-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    margin-right: 10px;
}

.wrm-method-get {
    background: #dcfce7;
    color: #166534;
}

.wrm-method-post {
    background: #dbeafe;
    color: #1e40af;
}

.wrm-card-body pre {
    background: #f6f7f7;
    padding: 15px;
    border-radius: 4px;
    overflow-x: auto;
    border: 1px solid #e1e5e9;
}

.wrm-card-body code {
    background: #f6f7f7;
    padding: 2px 4px;
    border-radius: 3px;
    font-size: 13px;
}

.wrm-card-body pre code {
    background: none;
    padding: 0;
}

.wrm-card-body h4 {
    margin: 20px 0 10px 0;
    font-size: 14px;
    font-weight: 600;
}

.wrm-card-body ul {
    margin: 10px 0;
    padding-left: 25px;
}

.wrm-card-body li {
    margin-bottom: 5px;
}
</style>