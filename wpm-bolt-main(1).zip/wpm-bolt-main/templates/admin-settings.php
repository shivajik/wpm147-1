<?php
if (!defined('ABSPATH')) {
    exit;
}

$api_key = get_option('wrm_api_key');
$allowed_ips = get_option('wrm_allowed_ips', array());
$log_retention_days = get_option('wrm_log_retention_days', 30);
$site_health_enabled = get_option('wrm_site_health_enabled', true);
?>

<div class="wrap wrm-admin">
    <h1><?php _e('Remote Manager Settings', 'wp-remote-manager'); ?></h1>
    
    <form method="post" action="">
        <?php wp_nonce_field('wrm_admin_action', 'wrm_nonce'); ?>
        <input type="hidden" name="wrm_action" value="save_settings">
        
        <div class="wrm-settings-sections">
            <!-- API Settings -->
            <div class="wrm-card">
                <div class="wrm-card-header">
                    <h2><?php _e('API Settings', 'wp-remote-manager'); ?></h2>
                </div>
                <div class="wrm-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('API Key', 'wp-remote-manager'); ?></th>
                            <td>
                                <div class="wrm-api-key-field">
                                    <input type="text" value="<?php echo esc_attr($api_key); ?>" readonly class="regular-text" id="wrm-api-key-display">
                                    <button type="button" class="button" id="wrm-generate-key">
                                        <?php _e('Generate New Key', 'wp-remote-manager'); ?>
                                    </button>
                                </div>
                                <p class="description">
                                    <?php _e('This key is required for all API requests. Keep it secure and do not share it publicly.', 'wp-remote-manager'); ?>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('API Endpoint', 'wp-remote-manager'); ?></th>
                            <td>
                                <code><?php echo esc_html(home_url('/wp-json/wrm/v1/')); ?></code>
                                <p class="description">
                                    <?php _e('Use this endpoint URL for all API requests to your site.', 'wp-remote-manager'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Security Settings -->
            <div class="wrm-card">
                <div class="wrm-card-header">
                    <h2><?php _e('Security Settings', 'wp-remote-manager'); ?></h2>
                </div>
                <div class="wrm-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Allowed IP Addresses', 'wp-remote-manager'); ?></th>
                            <td>
                                <textarea name="wrm_allowed_ips" rows="10" cols="50" class="large-text code"><?php echo esc_textarea(implode("\n", $allowed_ips)); ?></textarea>
                                <p class="description">
                                    <?php _e('Enter one IP address or CIDR range per line. Leave empty to allow all IPs. Examples:', 'wp-remote-manager'); ?>
                                    <br><code>192.168.1.100</code>
                                    <br><code>192.168.1.0/24</code>
                                    <br><code>2001:db8::/32</code>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Logging Settings -->
            <div class="wrm-card">
                <div class="wrm-card-header">
                    <h2><?php _e('Logging Settings', 'wp-remote-manager'); ?></h2>
                </div>
                <div class="wrm-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Log Retention Period', 'wp-remote-manager'); ?></th>
                            <td>
                                <input type="number" name="wrm_log_retention_days" value="<?php echo esc_attr($log_retention_days); ?>" min="1" max="365" class="small-text">
                                <?php _e('days', 'wp-remote-manager'); ?>
                                <p class="description">
                                    <?php _e('How long to keep activity logs. Older logs will be automatically deleted.', 'wp-remote-manager'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <!-- Health Monitoring Settings -->
            <div class="wrm-card">
                <div class="wrm-card-header">
                    <h2><?php _e('Health Monitoring', 'wp-remote-manager'); ?></h2>
                </div>
                <div class="wrm-card-body">
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Site Health Monitoring', 'wp-remote-manager'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="wrm_site_health_enabled" value="1" <?php checked($site_health_enabled); ?>>
                                    <?php _e('Enable automatic site health checks', 'wp-remote-manager'); ?>
                                </label>
                                <p class="description">
                                    <?php _e('Automatically monitor your site health and performance metrics.', 'wp-remote-manager'); ?>
                                </p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <?php submit_button(); ?>
    </form>
    
    <!-- Test Connection -->
    <div class="wrm-card">
        <div class="wrm-card-header">
            <h2><?php _e('Connection Test', 'wp-remote-manager'); ?></h2>
        </div>
        <div class="wrm-card-body">
            <p><?php _e('Test your API connection to ensure everything is working correctly.', 'wp-remote-manager'); ?></p>
            <button type="button" class="button button-primary" id="wrm-test-connection">
                <?php _e('Test Connection', 'wp-remote-manager'); ?>
            </button>
            <div id="wrm-connection-result" class="wrm-test-result"></div>
        </div>
    </div>
</div>