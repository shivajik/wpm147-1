<?php
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap wrm-admin">
    <h1><?php _e('Activity Logs', 'wp-remote-manager'); ?></h1>
    
    <!-- Filters -->
    <div class="wrm-card">
        <div class="wrm-card-header">
            <h2><?php _e('Filter Logs', 'wp-remote-manager'); ?></h2>
        </div>
        <div class="wrm-card-body">
            <form method="get" action="">
                <input type="hidden" name="page" value="wrm-logs">
                <div style="display: flex; gap: 15px; align-items: end;">
                    <div>
                        <label for="action_filter"><?php _e('Action:', 'wp-remote-manager'); ?></label>
                        <select name="action_filter" id="action_filter">
                            <option value=""><?php _e('All Actions', 'wp-remote-manager'); ?></option>
                            <option value="api_status_check" <?php selected($_GET['action_filter'] ?? '', 'api_status_check'); ?>><?php _e('Status Check', 'wp-remote-manager'); ?></option>
                            <option value="api_updates_check" <?php selected($_GET['action_filter'] ?? '', 'api_updates_check'); ?>><?php _e('Updates Check', 'wp-remote-manager'); ?></option>
                            <option value="maintenance_mode_toggled" <?php selected($_GET['action_filter'] ?? '', 'maintenance_mode_toggled'); ?>><?php _e('Maintenance Mode', 'wp-remote-manager'); ?></option>
                            <option value="health_check_completed" <?php selected($_GET['action_filter'] ?? '', 'health_check_completed'); ?>><?php _e('Health Check', 'wp-remote-manager'); ?></option>
                        </select>
                    </div>
                    <div>
                        <label for="status_filter"><?php _e('Status:', 'wp-remote-manager'); ?></label>
                        <select name="status_filter" id="status_filter">
                            <option value=""><?php _e('All Statuses', 'wp-remote-manager'); ?></option>
                            <option value="success" <?php selected($_GET['status_filter'] ?? '', 'success'); ?>><?php _e('Success', 'wp-remote-manager'); ?></option>
                            <option value="error" <?php selected($_GET['status_filter'] ?? '', 'error'); ?>><?php _e('Error', 'wp-remote-manager'); ?></option>
                            <option value="warning" <?php selected($_GET['status_filter'] ?? '', 'warning'); ?>><?php _e('Warning', 'wp-remote-manager'); ?></option>
                        </select>
                    </div>
                    <div>
                        <?php submit_button(__('Filter', 'wp-remote-manager'), 'secondary', 'filter', false); ?>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Clear Logs Button -->
    <form method="post" action="" style="margin-bottom: 20px;">
        <?php wp_nonce_field('wrm_admin_action', 'wrm_nonce'); ?>
        <input type="hidden" name="wrm_action" value="clear_logs">
        <button type="submit" class="button wrm-danger" onclick="return confirm('<?php _e('Are you sure you want to clear all logs?', 'wp-remote-manager'); ?>')">
            <?php _e('Clear All Logs', 'wp-remote-manager'); ?>
        </button>
    </form>
    
    <!-- Logs Table -->
    <div class="wrm-card">
        <div class="wrm-card-header">
            <h2><?php _e('Recent Activity', 'wp-remote-manager'); ?></h2>
        </div>
        <div class="wrm-card-body">
            <?php if (!empty($logs)): ?>
                <div class="wrm-logs-table">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th style="width: 200px;"><?php _e('Action', 'wp-remote-manager'); ?></th>
                                <th><?php _e('Details', 'wp-remote-manager'); ?></th>
                                <th style="width: 80px;"><?php _e('Status', 'wp-remote-manager'); ?></th>
                                <th style="width: 120px;"><?php _e('IP Address', 'wp-remote-manager'); ?></th>
                                <th style="width: 150px;"><?php _e('Date', 'wp-remote-manager'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo esc_html(str_replace('_', ' ', ucwords($log->action, '_'))); ?></strong>
                                    </td>
                                    <td>
                                        <?php if (!empty($log->details)): ?>
                                            <span title="<?php echo esc_attr($log->details); ?>">
                                                <?php echo esc_html(wp_trim_words($log->details, 15)); ?>
                                            </span>
                                        <?php else: ?>
                                            <em><?php _e('No details', 'wp-remote-manager'); ?></em>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="wrm-status-badge wrm-status-<?php echo esc_attr($log->status); ?>">
                                            <?php echo esc_html(ucfirst($log->status)); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <code><?php echo esc_html($log->ip_address); ?></code>
                                    </td>
                                    <td>
                                        <?php echo esc_html(mysql2date('M j, Y H:i', $log->created_at)); ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination would go here if needed -->
                
            <?php else: ?>
                <p><?php _e('No activity logs found.', 'wp-remote-manager'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>