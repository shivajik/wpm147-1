<?php
/**
 * Plugin Name: WP Remote Manager
 * Plugin URI: https://example.com/wp-remote-manager
 * Description: A comprehensive WordPress maintenance plugin that enables remote management and monitoring of your WordPress sites from a central dashboard.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-remote-manager
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WRM_VERSION', '1.0.0');
define('WRM_PLUGIN_FILE', __FILE__);
define('WRM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WRM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WRM_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include required files
require_once WRM_PLUGIN_DIR . 'includes/class-wp-remote-manager.php';
require_once WRM_PLUGIN_DIR . 'includes/class-wrm-database.php';
require_once WRM_PLUGIN_DIR . 'includes/class-wrm-admin.php';
require_once WRM_PLUGIN_DIR . 'includes/class-wrm-api.php';
require_once WRM_PLUGIN_DIR . 'includes/class-wrm-security.php';
require_once WRM_PLUGIN_DIR . 'includes/class-wrm-site-health.php';
require_once WRM_PLUGIN_DIR . 'includes/class-wrm-backup.php';

// Initialize the plugin
function wrm_init() {
    return WP_Remote_Manager::get_instance();
}

// Start the plugin
add_action('plugins_loaded', 'wrm_init');

// Activation hook
register_activation_hook(__FILE__, array('WP_Remote_Manager', 'activate'));

// Deactivation hook
register_deactivation_hook(__FILE__, array('WP_Remote_Manager', 'deactivate'));

// Uninstall hook
register_uninstall_hook(__FILE__, array('WP_Remote_Manager', 'uninstall'));