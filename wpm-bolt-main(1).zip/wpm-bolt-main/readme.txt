=== WP Remote Manager ===
Contributors: yourname
Tags: remote, management, monitoring, maintenance, api
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A comprehensive WordPress maintenance plugin that enables remote management and monitoring of your WordPress sites from a central dashboard.

== Description ==

WP Remote Manager is a powerful WordPress plugin that allows you to remotely manage and monitor your WordPress websites from a central dashboard. Perfect for agencies, freelancers, and anyone managing multiple WordPress sites.

= Key Features =

* **Remote Site Monitoring**: Monitor site health, performance, and statistics from your central dashboard
* **Automatic Updates**: Remotely update WordPress core, plugins, and themes
* **Backup Management**: Create and manage site backups remotely
* **Maintenance Mode**: Toggle maintenance mode on/off remotely
* **Security Features**: API key authentication and IP whitelisting
* **Activity Logging**: Comprehensive logging of all maintenance activities
* **Real-time Status**: Get real-time information about your sites' health and status
* **REST API**: Full REST API for integration with external applications
* **Site Health Monitoring**: Track SSL status, PHP version, and update status
* **User-Friendly Interface**: Clean, modern WordPress admin interface

= How It Works =

1. Install and activate WP Remote Manager on your WordPress sites
2. Configure the plugin settings and generate API keys
3. Connect your sites to your central management dashboard
4. Monitor, update, and maintain all your sites from one location

= API Endpoints =

* `GET /wp-json/wrm/v1/status` - Get site status and information
* `GET /wp-json/wrm/v1/updates` - Get available updates
* `POST /wp-json/wrm/v1/updates/{type}` - Perform updates (wordpress, plugins, themes)
* `POST /wp-json/wrm/v1/backup` - Create site backup
* `POST /wp-json/wrm/v1/maintenance` - Toggle maintenance mode

= Security =

* API key authentication for all remote connections
* IP address whitelisting for additional security
* Secure data transmission
* Activity logging for audit trails
* WordPress nonce verification for admin actions

= Perfect For =

* Web agencies managing multiple client sites
* Freelancers with multiple WordPress projects
* Site administrators who need centralized control
* Anyone who wants to streamline WordPress maintenance

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/wp-remote-manager` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Navigate to the Remote Manager menu in your WordPress admin
4. Configure your settings and generate your API key
5. Use the API key to connect your site to your remote management dashboard

== Frequently Asked Questions ==

= Is this plugin secure? =

Yes, WP Remote Manager uses API key authentication and supports IP whitelisting to ensure only authorized connections can access your site. All admin actions use WordPress nonce verification.

= Can I use this plugin with any management dashboard? =

The plugin provides a standard REST API that can be integrated with any management system that supports HTTP requests and API authentication.

= What happens if I deactivate the plugin? =

Remote access will be disabled immediately. Your site will continue to function normally, but remote management features will not be available. All plugin data and logs will remain in the database.

= Does this plugin affect site performance? =

The plugin is designed to have minimal impact on site performance. It only activates when receiving remote requests or during scheduled maintenance tasks.

= Can I restrict access by IP address? =

Yes, you can configure IP whitelisting in the plugin settings to restrict API access to specific IP addresses or ranges.

= What information does the plugin collect? =

The plugin collects site statistics (WordPress version, PHP version, plugin/theme counts, etc.) and logs maintenance activities. No personal user data is transmitted unless explicitly configured.

= Can I backup my site with this plugin? =

The plugin includes basic backup functionality through the API. For production use, we recommend integrating with dedicated backup solutions.

== Screenshots ==

1. Main dashboard showing site health and statistics
2. Settings page with API configuration and security options
3. Activity logs showing maintenance history with filtering
4. Site information overview with system details
5. API documentation and example requests

== Changelog ==

= 1.0.0 =
* Initial release
* Remote site monitoring and status reporting
* WordPress core, plugin, and theme update management
* Basic backup functionality
* Maintenance mode toggle
* API key authentication with IP whitelisting
* Comprehensive activity logging
* Modern WordPress admin interface
* REST API with full documentation
* Site health scoring and monitoring
* Real-time connection testing

== Upgrade Notice ==

= 1.0.0 =
Initial release of WP Remote Manager. Install to start managing your WordPress sites remotely.

== Support ==

For support, documentation, and feature requests, please visit our website or contact us through the WordPress.org support forums.

== Privacy Policy ==

WP Remote Manager collects and stores activity logs and site statistics for maintenance purposes. No personal data is transmitted to external servers unless explicitly configured by the site administrator. All data remains on your WordPress installation.

== Technical Requirements ==

* WordPress 5.0 or higher
* PHP 7.4 or higher
* MySQL 5.6 or higher
* cURL support for API functionality
* Sufficient file permissions for backup operations (if used)

== Developer Information ==

This plugin provides hooks and filters for developers:

* `wrm_before_api_call` - Action fired before API calls
* `wrm_after_api_call` - Action fired after API calls
* `wrm_log_activity` - Action for custom activity logging
* `wrm_site_health_score` - Filter to modify site health calculation