jQuery(document).ready(function($) {
    'use strict';
    
    // Initialize dashboard
    initDashboard();
    initHealthScores();
    
    // Test Connection
    $('#wrm-test-connection').on('click', function() {
        var $button = $(this);
        var $result = $('#wrm-connection-result');
        
        $button.prop('disabled', true).text(wrm_ajax.strings.testing_connection);
        $result.removeClass('success error').hide();
        
        $.ajax({
            url: wrm_ajax.url,
            method: 'POST',
            data: {
                action: 'wrm_test_connection',
                nonce: wrm_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $result.addClass('success').text(response.data.message).fadeIn();
                } else {
                    $result.addClass('error').text(response.data.message).fadeIn();
                }
            },
            error: function() {
                $result.addClass('error').text(wrm_ajax.strings.connection_failed).fadeIn();
            },
            complete: function() {
                $button.prop('disabled', false).text('Test Connection');
            }
        });
    });
    
    // Generate API Key
    $('#wrm-generate-key').on('click', function() {
        if (!confirm(wrm_ajax.strings.confirm_generate)) {
            return;
        }
        
        var $button = $(this);
        var $input = $('#wrm-api-key-display, .wrm-api-key-field input[readonly]');
        
        $button.prop('disabled', true);
        
        $.ajax({
            url: wrm_ajax.url,
            method: 'POST',
            data: {
                action: 'wrm_generate_api_key',
                nonce: wrm_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    $input.val(response.data.api_key);
                    showNotice(response.data.message, 'success');
                } else {
                    showNotice(response.data.message, 'error');
                }
            },
            error: function() {
                showNotice('Failed to generate API key', 'error');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });
    
    // Copy to clipboard functionality
    $(document).on('click', '.wrm-api-info code, .wrm-api-key-field input[readonly]', function() {
        var text = $(this).is('input') ? $(this).val() : $(this).text();
        
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function() {
                showNotice('Copied to clipboard!', 'success', 1500);
            });
        } else {
            // Fallback for older browsers
            var $temp = $('<input>');
            $('body').append($temp);
            $temp.val(text).select();
            document.execCommand('copy');
            $temp.remove();
            showNotice('Copied to clipboard!', 'success', 1500);
        }
    });
    
    // Auto-refresh health data
    if ($('.wrm-health-score').length) {
        setInterval(function() {
            refreshHealthData();
        }, 60000); // Refresh every minute
    }
    
    // Log filtering
    $('#wrm-log-filter').on('change', function() {
        var filterValue = $(this).val();
        filterLogs(filterValue);
    });
    
    // Initialize functions
    function initDashboard() {
        // Add loading states
        $('.wrm-card').addClass('wrm-fade-in');
        
        // Handle form submissions
        $('form').on('submit', function() {
            $(this).find('input[type="submit"]').prop('disabled', true);
        });
    }
    
    function initHealthScores() {
        $('.wrm-score-circle').each(function() {
            var score = $(this).data('score');
            $(this).css('--score', score);
            
            // Color based on score
            var color = '#ef4444'; // red
            if (score >= 80) {
                color = '#10b981'; // green
            } else if (score >= 60) {
                color = '#f59e0b'; // yellow
            }
            
            $(this).css('background', 
                'conic-gradient(' + color + ' 0deg, ' + color + ' ' + (score * 3.6) + 'deg, #e5e7eb ' + (score * 3.6) + 'deg, #e5e7eb 360deg)'
            );
        });
    }
    
    function refreshHealthData() {
        $.ajax({
            url: wrm_ajax.url,
            method: 'POST',
            data: {
                action: 'wrm_refresh_health',
                nonce: wrm_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    updateHealthDisplay(response.data);
                }
            }
        });
    }
    
    function updateHealthDisplay(healthData) {
        // Update overall score
        var $scoreCircle = $('.wrm-score-circle');
        var overallScore = healthData.overall_score;
        
        $scoreCircle.find('.wrm-score-text').text(overallScore + '%');
        $scoreCircle.data('score', overallScore);
        
        // Update individual categories
        $('.wrm-health-item').each(function() {
            var category = $(this).find('.wrm-health-label').text().toLowerCase();
            if (healthData[category]) {
                var $status = $(this).find('.wrm-health-status');
                $status.removeClass('wrm-status-good wrm-status-warning wrm-status-critical')
                       .addClass('wrm-status-' + healthData[category].status)
                       .text(healthData[category].score + '%');
            }
        });
        
        // Update last check time
        $('.wrm-last-check').text('Last check: ' + new Date().toLocaleString());
        
        // Re-initialize health scores
        initHealthScores();
    }
    
    function filterLogs(filterValue) {
        $('.wrm-logs-table tbody tr').each(function() {
            var $row = $(this);
            var action = $row.find('td:first').text().toLowerCase();
            var status = $row.find('.wrm-status-badge').text().toLowerCase();
            
            if (filterValue === '' || action.includes(filterValue) || status.includes(filterValue)) {
                $row.show();
            } else {
                $row.hide();
            }
        });
    }
    
    function showNotice(message, type, duration) {
        type = type || 'info';
        duration = duration || 3000;
        
        var $notice = $('<div class="notice notice-' + type + ' is-dismissible wrm-notice"><p>' + message + '</p></div>');
        
        $('.wrap > h1').after($notice);
        
        // Auto-hide notice
        setTimeout(function() {
            $notice.fadeOut(function() {
                $(this).remove();
            });
        }, duration);
        
        // Handle dismiss button
        $notice.on('click', '.notice-dismiss', function() {
            $notice.fadeOut(function() {
                $(this).remove();
            });
        });
    }
    
    // Smooth scrolling for anchor links
    $('a[href^="#"]').on('click', function(event) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            event.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 50
            }, 1000);
        }
    });
    
    // Enhanced tooltips
    $('[data-tooltip]').each(function() {
        $(this).attr('title', $(this).data('tooltip'));
    });
    
    // Keyboard shortcuts
    $(document).on('keydown', function(e) {
        // Ctrl/Cmd + K for connection test
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 75) {
            e.preventDefault();
            $('#wrm-test-connection').trigger('click');
        }
        
        // Ctrl/Cmd + G for generate API key
        if ((e.ctrlKey || e.metaKey) && e.keyCode === 71) {
            e.preventDefault();
            $('#wrm-generate-key').trigger('click');
        }
    });
    
    // Form validation
    $('form[method="post"]').on('submit', function(e) {
        var $form = $(this);
        var isValid = true;
        
        // Validate IP addresses
        var $ipField = $form.find('[name="wrm_allowed_ips"]');
        if ($ipField.length) {
            var ips = $ipField.val().split('\n');
            var ipRegex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\/(?:[0-9]|[1-2][0-9]|3[0-2]))?$/;
            
            for (var i = 0; i < ips.length; i++) {
                var ip = ips[i].trim();
                if (ip && !ipRegex.test(ip)) {
                    showNotice('Invalid IP address format: ' + ip, 'error');
                    $ipField.focus();
                    isValid = false;
                    break;
                }
            }
        }
        
        if (!isValid) {
            e.preventDefault();
        }
    });
    
    // Auto-save settings (draft)
    var autoSaveTimer;
    $('.wrm-settings-sections input, .wrm-settings-sections textarea, .wrm-settings-sections select').on('change', function() {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(function() {
            // Could implement auto-save draft functionality here
        }, 2000);
    });
    
    // Table row highlighting
    $('.wp-list-table tbody tr').hover(
        function() {
            $(this).addClass('hover');
        },
        function() {
            $(this).removeClass('hover');
        }
    );
    
    // Real-time status updates
    if (window.EventSource && $('.wrm-dashboard-grid').length) {
        // Could implement Server-Sent Events for real-time updates
    }
    
    // Accessibility enhancements
    $(document).on('keydown', '.wrm-card', function(e) {
        if (e.keyCode === 13 || e.keyCode === 32) { // Enter or Space
            var $link = $(this).find('a').first();
            if ($link.length) {
                window.location.href = $link.attr('href');
            }
        }
    });
    
    // Initialize chart if available
    if (typeof Chart !== 'undefined' && $('.wrm-health-chart').length) {
        initHealthChart();
    }
    
    function initHealthChart() {
        // Health score chart implementation would go here
        // This is a placeholder for potential chart visualization
    }
});